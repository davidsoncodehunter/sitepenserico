# Bot Bitget — Como começar

Bot automático de trading para **futuros COIN-M perpétuo** na Bitget.
Painel web para acompanhar saldo, posições e log ao vivo.

---

## 1. O que você precisa instalado

| Software | Como instalar |
|---|---|
| Python 3.9+ | https://www.python.org/downloads/ (marque **"Add Python to PATH"** no Windows) |
| Node.js LTS | https://nodejs.org |

Pronto. O resto o script instala sozinho.

---

## 2. Instalar (uma vez só)

### Mac ou Linux

Abra o **Terminal** na pasta deste projeto e rode:
```bash
./instalar.sh
```

### Windows

Abra o **PowerShell** na pasta deste projeto e rode:
```powershell
python -m venv .venv
.venv\Scripts\pip install --upgrade pip
.venv\Scripts\pip install aiohttp pandas numpy anthropic python-dotenv ta cryptography scikit-learn streamlit requests
npm install -g pm2
copy .env.example .env
```

> O script demora 2-3 minutos para baixar tudo.

---

## 3. Iniciar

### Mac ou Linux

```bash
./iniciar.sh
```

### Windows

```powershell
pm2 start bitget_perpetual_agent.py --interpreter .venv\Scripts\python.exe --name bitget-bot --output trading_agent.log --error trading_agent.log
pm2 start .venv\Scripts\streamlit.exe --name bitget-painel --interpreter none -- run painel/Home.py --server.port 8501 --server.headless true
start http://localhost:8501
```

---

## 4. Configurar suas chaves Bitget

1. O navegador abre automaticamente em `http://localhost:8501`
2. No menu lateral, clique em **🔑 Configurar Bitget**
3. Siga o passo a passo da própria tela para gerar as chaves
4. Cole **API Key**, **Secret** e **Passphrase**
5. Clique em **✅ Testar e salvar**
6. Reinicie o bot: `pm2 restart bitget-bot`

⚠️ **Permissões da API Key na Bitget**:
- ✅ Read
- ✅ Futures Trading
- ❌ Withdraw — **NUNCA** marque essa opção

---

## 5. Como saber que está rodando

No menu lateral do painel:
- **🤖 Home** — saldos, posições abertas, log do bot ao vivo
- **🔑 Configurar Bitget** — formulário das chaves

Ou no terminal:
```bash
pm2 status              # ver se os 2 processos estão online
pm2 logs bitget-bot     # ver o log ao vivo (Ctrl+C para sair)
```

---

## 6. Como o bot decide entrar (resumo)

O bot monitora **15 moedas** automaticamente e opera **só as moedas em que
você tem saldo** na conta COIN-M Futuros. Estratégia em duas camadas:

1. **Tendência** (1D, 4H, 1H) — confirma direção em pelo menos 2 timeframes
2. **Entrada** (5m, 15m) — gatilho de RSI extremo (≤20 LONG / ≥80 SHORT)

Depois de abrir, ele gerencia ativamente: **breakeven**, **trailing stop**,
**parciais** (realiza 40% no primeiro alvo, 40% no segundo, deixa 20%
correrem) e pirâmide quando a tendência confirma.

---

## 7. Comandos úteis

| O que fazer | Comando |
|---|---|
| Ver status | `pm2 status` |
| Ver log do bot ao vivo | `pm2 logs bitget-bot` |
| Reiniciar bot | `pm2 restart bitget-bot` |
| Reiniciar painel | `pm2 restart bitget-painel` |
| Parar tudo | `./parar.sh` (ou `pm2 stop bitget-bot bitget-painel`) |
| Remover do pm2 | `pm2 delete bitget-bot bitget-painel` |

---

## 8. Adicionar mais moedas

Basta depositar a moeda em **COIN-M Futuros** na Bitget. O bot detecta o
novo saldo automaticamente em até 5 minutos.

**Moedas suportadas (15):** BTC, ETH, DOT, SOL, XRP, ADA, LINK, LTC, AVAX,
BNB, MATIC, ATOM, NEAR, FIL, TRX.

---

## 9. Problemas comuns

**`pm2: command not found`**
→ `npm install -g pm2`

**`ModuleNotFoundError`**
→ Rode `./instalar.sh` de novo

**`apikey/password is incorrect`**
→ A Passphrase está errada. Vá em **🔑 Configurar Bitget** e corrija.

**`Apikey does not exist`**
→ A chave foi deletada na Bitget. Crie uma nova e cole no painel.

**Painel não abre em `localhost:8501`**
→ `pm2 logs bitget-painel --err` para ver o erro

**Bot só analisando, não entra em trade**
→ Comportamento normal. Pode passar horas sem operar — ele só entra
quando todas as confluências batem.

---

## 10. SEGURANÇA — leia antes de usar

- ✅ Suas chaves ficam **só no seu PC** (no `.env` local, modo 600)
- ✅ O `.gitignore` deste projeto bloqueia `.env` de versionar
- ❌ **NUNCA** compartilhe o `.env` com ninguém
- ❌ **NUNCA** suba o `.env` para Google Drive, GitHub, Dropbox, etc.
- ❌ **NUNCA** mostre o conteúdo em screenshot ou vídeo
- ❌ **NUNCA** marque a permissão **Withdraw** na API Key

Se desconfiar que suas chaves vazaram:
1. Vá em **bitget.com → API Management**
2. **Revogue** as chaves imediatamente
3. Gere chaves novas
4. Atualize no painel (aba 🔑 Configurar Bitget)

---

## 11. Avisos importantes

- Este bot **opera dinheiro real**. Comece com saldo pequeno para testar.
- Trading de futuros tem **risco alto de perda**, inclusive perda total.
- O bot **não garante lucro** — segue uma estratégia técnica que pode
  errar como qualquer outra.
- Você é o **único responsável** pelas operações na sua conta.
