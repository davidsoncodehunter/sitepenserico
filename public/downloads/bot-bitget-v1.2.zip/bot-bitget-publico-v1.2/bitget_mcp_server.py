#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║         MCP SERVER - BITGET COIN-M TRADING AGENT                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

INSTALAÇÃO:
  pip install -r requirements.txt

CONFIGURAÇÃO:
  export BITGET_API_KEY="sua_chave"
  export BITGET_API_SECRET="seu_secret"
  export BITGET_PASSPHRASE="seu_passphrase"

EXECUÇÃO:
  python bitget_mcp_server.py
"""

import json
import asyncio
import os
from typing import Any, Optional
from datetime import datetime
import sys

sys.path.insert(0, os.path.dirname(__file__))
from bitget_perpetual_agent import (
    BitgetTradingAgent,
    StrategyConfig,
    AdvancedAnalyzer,
    BitgetPerpetualAPI,
)


# Ativos padrão — COIN-M (símbolo termina em USD)
DEFAULT_SYMBOLS = ["DOTUSD", "BTCUSD", "ETHUSD", "SOLUSD", "BNBUSD", "ADAUSD"]
DEFAULT_TIMEFRAMES = ["5m", "15m", "1h"]


class MCPTradingServer:

    def __init__(self):
        self.agent = None
        self.api   = None
        self.analyzer = AdvancedAnalyzer()
        self._setup_agent()

    def _setup_agent(self):
        api_key    = os.getenv("BITGET_API_KEY")
        api_secret = os.getenv("BITGET_API_SECRET")
        passphrase = os.getenv("BITGET_PASSPHRASE")

        if not all([api_key, api_secret, passphrase]):
            raise ValueError(
                "Defina as variáveis de ambiente:\n"
                "  BITGET_API_KEY, BITGET_API_SECRET, BITGET_PASSPHRASE"
            )

        strategy = StrategyConfig(
            name="MULTI_TF_RSI_MACD",
            enabled=True,
            leverage=5,
            risk_percent=0.02,
            max_positions=6,
            use_stop_loss=True,
            use_take_profit=True,
            tp_levels=2,
            trailing_stop=False,
        )

        self.agent = BitgetTradingAgent(
            api_key=api_key,
            api_secret=api_secret,
            passphrase=passphrase,
            account_balance=1000,
            symbols=DEFAULT_SYMBOLS,
            strategy_config=strategy,
            product_type="dmcbl",
            timeframes=DEFAULT_TIMEFRAMES,
            check_interval=15,
            testnet=True,
        )

    # ── FERRAMENTAS MCP ───────────────────────────────────────────────────────

    async def analyze_symbol(self, symbol: str) -> dict:
        """Analisa um símbolo com multi-timeframe e retorna sinal de long/short"""
        try:
            signal = await self.agent.analyze_symbol(symbol)
            if not signal:
                return {"status": "no_signal", "symbol": symbol, "message": "Sem consenso nos timeframes"}

            return {
                "status": "success",
                "symbol": symbol,
                "signal": {
                    "direction":    signal.position_mode.value.upper(),
                    "confidence":   f"{signal.confidence:.1f}%",
                    "strength":     signal.signal_strength.name,
                    "timeframes":   signal.timeframe,
                    "entry":        f"{signal.entry_price:.6f}",
                    "stop_loss":    f"{signal.stop_loss:.6f}",
                    "take_profit_1":f"{signal.take_profit_1:.6f}",
                    "take_profit_2":f"{signal.take_profit_2:.6f}",
                    "leverage":     f"{signal.leverage}x",
                    "quantity":     f"{signal.quantity:.4f}",
                    "risk_reward":  f"{signal.risk_reward_ratio:.2f}:1",
                    "analysis":     signal.analysis[:300],
                },
            }
        except Exception as e:
            return {"status": "error", "symbol": symbol, "error": str(e)}

    async def analyze_all(self) -> dict:
        """Analisa todos os ativos configurados em paralelo"""
        import asyncio
        results = await asyncio.gather(
            *[self.analyze_symbol(s) for s in self.agent.symbols],
            return_exceptions=True
        )
        return {
            "status": "success",
            "symbols_analyzed": len(self.agent.symbols),
            "results": [r if not isinstance(r, Exception) else {"error": str(r)} for r in results],
        }

    async def get_market_data(self, symbol: str) -> dict:
        """Preço e dados de mercado em tempo real"""
        try:
            async with self.agent.api as api:
                ticker = await api.get_ticker(symbol)
                if ticker.get("code") != "00000":
                    return {"status": "error", "error": ticker.get("message")}
                data = ticker.get("data", [{}])
                if isinstance(data, list):
                    data = data[0] if data else {}
                return {
                    "status": "success",
                    "symbol": symbol,
                    "price":      data.get("lastPr"),
                    "change_24h": data.get("change24h"),
                    "high_24h":   data.get("high24h"),
                    "low_24h":    data.get("low24h"),
                    "volume":     data.get("baseVolume"),
                    "timestamp":  datetime.now().isoformat(),
                }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def get_account_info(self) -> dict:
        """Saldo e informações da conta"""
        try:
            async with self.agent.api as api:
                balance = await api.get_balance()
                return {"status": "success", "balance": balance.get("data", [])}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def get_positions(self, symbol: Optional[str] = None) -> dict:
        """Lista posições abertas (todas ou de um símbolo específico)"""
        try:
            async with self.agent.api as api:
                positions = await api.get_open_positions(symbol)
                return {"status": "success", "symbol": symbol or "todos", "positions": positions}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def place_trade(
        self,
        symbol: str,
        side: str,           # "long" ou "short"
        quantity: float,
        leverage: int = 5,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Coloca ordem de long ou short"""
        try:
            if self.agent.testnet:
                return {
                    "status": "simulated",
                    "symbol": symbol,
                    "side": side,
                    "quantity": quantity,
                    "leverage": leverage,
                    "message": "Simulado (testnet=True). Mude para False para operar de verdade.",
                }

            async with self.agent.api as api:
                order_side = "buy" if side == "long" else "sell"
                result = await api.place_order(
                    symbol=symbol,
                    side=order_side,
                    position_side=side,
                    order_type="market",
                    quantity=quantity,
                    leverage=leverage,
                    stop_loss=stop_loss,
                    take_profit=take_profit,
                )
                return {"status": "success" if result.get("code") == "00000" else "error", "result": result}

        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def close_position(self, symbol: str, side: str) -> dict:
        """Fecha posição (side: 'long' ou 'short')"""
        try:
            async with self.agent.api as api:
                result = await api.close_position(symbol, side)
                return {"status": "success", "result": result}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def get_trading_history(self) -> dict:
        return {
            "status": "success",
            "total_trades": len(self.agent.trade_history),
            "trades": self.agent.trade_history[-20:],
        }

    async def set_symbols(self, symbols: list) -> dict:
        """Altera os ativos monitorados em tempo real"""
        self.agent.symbols = symbols
        return {"status": "success", "symbols": symbols}

    async def set_leverage(self, leverage: int) -> dict:
        """Altera a alavancagem"""
        self.agent.strategy.leverage = leverage
        return {"status": "success", "leverage": leverage}


# ============================================================================
# CLI DE TESTE
# ============================================================================

async def cli_test():
    print("""
╔════════════════════════════════════════════════════════════╗
║     BITGET COIN-M TRADING MCP SERVER — TESTE               ║
╚════════════════════════════════════════════════════════════╝
    """)

    server = MCPTradingServer()

    print("📊 Analisando DOTUSD (multi-timeframe)...")
    result = await server.analyze_symbol("DOTUSD")
    print(json.dumps(result, indent=2))

    print("\n📊 Análise paralela de todos os ativos...")
    result = await server.analyze_all()
    print(json.dumps(result, indent=2))

    print("\n💰 Saldo da conta...")
    result = await server.get_account_info()
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    print("🚀 Iniciando Bitget COIN-M MCP Server...")
    try:
        asyncio.run(cli_test())
    except KeyboardInterrupt:
        print("\n⛔ Servidor interrompido")
    except ValueError as e:
        print(f"\n❌ {e}")
    except Exception as e:
        print(f"\n❌ Erro: {e}")
