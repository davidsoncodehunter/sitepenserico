#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║         ROBÔ DE TRADING PERPETUAL (COIN-M) BITGET — v4 INTELIGENTE          ║
║                                                                              ║
║  Estratégia em duas camadas:                                                 ║
║    Camada 1 — TENDÊNCIA:  1h + 4h + 1d  (filtro de direção)                 ║
║    Camada 2 — ENTRADA:    5m + 15m       (gatilho de operação)               ║
║                                                                              ║
║  Gestão ativa de posição:                                                    ║
║    • Pirâmide: adiciona posição quando tendência confirma                    ║
║    • TP dinâmico: fecha na resistência/suporte ou RSI extremo                ║
║    • Trailing stop: SL acompanha o preço em tendência forte                  ║
║    • Parcial: realiza 40% no primeiro alvo, deixa o resto correr             ║
║    • Breakeven: move SL para entrada após lucro inicial                      ║
║    • Reentrada: detecta pullback em tendência forte e reabre posição         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import json
import time
import hmac
import hashlib
import base64
import logging
import os
from datetime import datetime
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import aiohttp
import pandas as pd
import numpy as np
from pathlib import Path
import sys

# Carrega .env automaticamente se existir
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

# ============================================================================
# LOGGING
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(message)s',
    handlers=[
        logging.FileHandler('trading_agent.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


# ============================================================================
# ENUMS E DATACLASSES
# ============================================================================

class Direction(Enum):
    LONG  = "long"
    SHORT = "short"
    NONE  = "none"


class PositionPhase(Enum):
    ENTRY      = "entry"      # posição recém aberta
    BREAKEVEN  = "breakeven"  # SL movido para entrada
    TRAILING   = "trailing"   # SL seguindo o preço
    PARTIAL1   = "partial1"   # primeiro parcial realizado
    PARTIAL2   = "partial2"   # segundo parcial realizado


@dataclass
class TrendBias:
    direction: Direction
    score: float
    confluence: int
    total_signals: int
    summary: str


@dataclass
class EntrySignal:
    direction: Direction
    score: float
    confluence: int
    total_signals: int
    price: float
    atr: float
    summary: str


@dataclass
class TradeSignal:
    symbol: str
    direction: Direction
    trend_score: float
    entry_score: float
    overall_confidence: float
    confluence_pct: float
    price: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    atr: float
    leverage: int
    summary: str
    timestamp: datetime


@dataclass
class PositionEntry:
    price: float
    qty: float
    timestamp: datetime


@dataclass
class OpenPosition:
    """Posição aberta com gestão ativa completa."""
    symbol: str
    direction: Direction
    entries: List[PositionEntry]
    avg_entry: float
    total_qty: float
    initial_sl: float
    current_sl: float
    tp1: float                        # primeiro alvo parcial (ATR)
    tp2: float                        # segundo alvo (resistência/suporte)
    tp3: float                        # terceiro alvo (RSI extremo ou afastado)
    atr: float
    confidence: float
    phase: PositionPhase = PositionPhase.ENTRY
    pyramid_count: int = 1
    partial_tp1_done: bool = False
    partial_tp2_done: bool = False
    breakeven_set: bool = False
    last_reentry_cycle: int = 0
    opened_at: datetime = field(default_factory=datetime.now)


@dataclass
class SimulatedTrade:
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    confidence: float
    confluence_pct: float
    timestamp: str
    result: str = "open"
    pnl_pct: float = 0.0


@dataclass
class StrategyConfig:
    name: str = "SCALP_MTF_v4"
    leverage: int = 3
    risk_percent: float = 0.01
    max_positions: int = 3

    # Thresholds de confluência
    min_trend_confluence: float = 0.60
    min_entry_confluence: float = 0.65
    min_overall_confidence: float = 0.62

    # TP/SL base (ATR)
    tp_atr_mult: float = 1.2
    sl_atr_mult: float = 0.7
    min_rr: float = 1.3

    # Pirâmide
    max_pyramid_entries: int = 3
    pyramid_min_confidence: float = 0.72
    pyramid_size_ratio: float = 0.5      # cada adição = 50% do tamanho anterior

    # Trailing stop
    breakeven_atr_mult: float = 0.8      # move SL para BE após +0.8 ATR de lucro
    trailing_start_mult: float = 1.5     # começa trailing após +1.5 ATR de lucro
    trailing_distance_mult: float = 1.0  # mantém SL a 1.0 ATR do preço atual

    # Parciais
    partial_tp1_pct: float = 0.40        # fecha 40% no primeiro alvo
    partial_tp2_pct: float = 0.40        # fecha 40% no segundo alvo
    # os 20% restantes ficam com trailing até RSI extremo ou SL

    # RSI Cascata — Filtro OBRIGATÓRIO (Elder Triple Screen)
    rsi_cascade_threshold: float = 20.0  # ≤20 = LONG / ≥80 = SHORT
    rsi_cascade_min_tfs: int = 2         # mínimo de TFs (1D, 4H, 1H) no extremo

    # RSI saída
    rsi_long_exit: float = 76.0          # fecha long quando RSI > 76
    rsi_short_exit: float = 24.0         # fecha short quando RSI < 24

    # Reentrada e proteção
    reentry_cooldown_cycles: int = 10    # ciclos de espera (10 × 30s = 5min)
    reentry_cooldown_seconds: int = 300  # mínimo 5 min após fechar qualquer posição
    max_consecutive_losses: int = 3      # pausa símbolo após 3 perdas seguidas
    max_daily_loss_pct: float = 0.08     # para de operar símbolo se perder >8% no dia


# ============================================================================
# API BITGET — COIN-M PERPETUAL
# ============================================================================

class BitgetPerpetualAPI:

    BASE_URL = "https://api.bitget.com"

    def __init__(self, api_key: str, api_secret: str, passphrase: str,
                 product_type: str = "COIN-FUTURES"):
        self.api_key      = api_key
        self.api_secret   = api_secret
        self.passphrase   = passphrase
        self.product_type = product_type
        self.session      = None

    @staticmethod
    def margin_coin(symbol: str) -> str:
        for suffix in ("USDT", "USD", "PERP"):
            if symbol.endswith(suffix):
                return symbol[: -len(suffix)].upper()
        return symbol.upper()

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *_):
        if self.session:
            await self.session.close()

    def _sign(self, ts: str, method: str, path: str, body: str = "") -> str:
        msg = ts + method + path + body
        mac = hmac.new(self.api_secret.encode(), msg.encode(), hashlib.sha256)
        return base64.b64encode(mac.digest()).decode()

    async def _request(self, method: str, endpoint: str,
                       params: dict = None, data: dict = None) -> dict:
        ts   = str(int(time.time() * 1000))
        path = f"/api/v2{endpoint}"
        body = json.dumps(data) if data else ""

        # Bitget v2: GET requer query string na assinatura
        if method == "GET" and params:
            query = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
            sign_path = f"{path}?{query}"
        else:
            sign_path = path

        headers = {
            "Content-Type":      "application/json",
            "ACCESS-KEY":        self.api_key,
            "ACCESS-SIGN":       self._sign(ts, method, sign_path, body),
            "ACCESS-TIMESTAMP":  ts,
            "ACCESS-PASSPHRASE": self.passphrase,
        }
        url = self.BASE_URL + path
        try:
            async with self.session.request(
                method, url, headers=headers,
                json=data, params=params,
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                return await resp.json()
        except asyncio.TimeoutError:
            return {"code": "timeout", "msg": "Timeout"}
        except Exception as e:
            return {"code": "error", "msg": str(e)}

    async def get_klines(self, symbol: str, granularity: str = "15m",
                         limit: int = 200) -> list:
        r = await self._request("GET", "/mix/market/candles", params={
            "symbol": symbol, "granularity": granularity,
            "limit": min(limit, 500), "productType": self.product_type,
        })
        return r.get("data", [])

    async def get_ticker(self, symbol: str) -> dict:
        return await self._request("GET", "/mix/market/ticker",
                                   params={"symbol": symbol,
                                           "productType": self.product_type})

    async def get_open_positions(self, symbol: str = None) -> list:
        params = {"productType": self.product_type}
        if symbol:
            params["symbol"] = symbol
        r = await self._request("GET", "/mix/position/allPosition", params=params)
        data = r.get("data")
        return data if isinstance(data, list) else []

    async def set_leverage(self, symbol: str, leverage: int, margin_coin: str) -> dict:
        data = {
            "symbol":      symbol,
            "marginCoin":  margin_coin,
            "leverage":    str(leverage),
            "productType": self.product_type,
        }
        return await self._request("POST", "/mix/account/set-leverage", data=data)

    async def place_order(self, symbol: str, side: str, position_side: str,
                          order_type: str, quantity: float, leverage: int,
                          stop_loss: float = None,
                          take_profit: float = None) -> dict:
        data = {
            "symbol":      symbol,
            "side":        side,       # buy / sell
            "tradeSide":   "open",     # sempre "open" ao abrir posição
            "orderType":   order_type,
            "marginMode":  "crossed",
            "size":        str(quantity),
            "productType": self.product_type,
            "marginCoin":  self.margin_coin(symbol),
            "leverage":    str(leverage),
        }
        # SL/TP gerenciados ativamente pelo monitor_positions — não preset na ordem
        return await self._request("POST", "/mix/order/place-order", data=data)

    async def close_position(self, symbol: str, position_side: str) -> dict:
        data = {
            "symbol":      symbol,
            "holdSide":    position_side,
            "productType": self.product_type,
            "marginCoin":  self.margin_coin(symbol),
        }
        return await self._request("POST", "/mix/order/close-positions", data=data)

    async def set_position_sl(self, symbol: str, position_side: str,
                               sl_price: float) -> dict:
        data = {
            "symbol":         symbol,
            "holdSide":       position_side,
            "productType":    self.product_type,
            "marginCoin":     self.margin_coin(symbol),
            "stopLossPrice":  str(round(sl_price, 6)),
        }
        return await self._request("POST", "/mix/order/modify-sl-tp", data=data)

    async def get_funding_rate(self, symbol: str) -> float:
        """Retorna a taxa de funding atual. Positiva = longs pagam shorts."""
        r = await self._request("GET", "/mix/market/current-fund-rate",
                                params={"symbol": symbol, "productType": self.product_type})
        try:
            return float((r.get("data") or [{}])[0].get("fundingRate", 0) or 0)
        except Exception:
            return 0.0

    async def get_open_interest(self, symbol: str) -> dict:
        """Retorna open interest atual e variação."""
        r = await self._request("GET", "/mix/market/open-interest",
                                params={"symbol": symbol, "productType": self.product_type})
        try:
            data = (r.get("data") or [{}])[0]
            return {
                "oi":       float(data.get("openInterestList", [{}])[0].get("size", 0) or 0),
                "oi_value": float(data.get("openInterestList", [{}])[0].get("value", 0) or 0),
            }
        except Exception:
            return {"oi": 0.0, "oi_value": 0.0}

    async def get_account_balances(self) -> Dict[str, float]:
        """
        Retorna dicionário {moeda: saldo} para COIN-M.
        Apenas moedas com saldo > 0 são retornadas.
        """
        r = await self._request("GET", "/mix/account/accounts",
                                params={"productType": self.product_type})
        balances = {}
        for item in (r.get("data") or []):
            coin   = item.get("marginCoin", "").upper()
            equity = float(item.get("accountEquity", 0) or 0)
            if equity > 0:
                balances[coin] = equity
        return balances


# ============================================================================
# INDICADORES TÉCNICOS — v4 COMPLETO
# ============================================================================

def build_df(klines: list) -> Optional[pd.DataFrame]:
    if not klines:
        return None
    if len(klines) < 60:
        return None
    cols = ["ts", "open", "high", "low", "close", "volume", "quote_vol"]
    df = pd.DataFrame(klines, columns=cols[:len(klines[0])])
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.dropna(subset=["open", "high", "low", "close", "volume"])


def calc_indicators(df: pd.DataFrame) -> Dict[str, float]:
    ind = {}
    c = df["close"]
    h = df["high"]
    l = df["low"]
    o = df["open"]
    v = df["volume"]

    # ── EMAs ────────────────────────────────────────────────────────────────
    ind["ema_10"]  = float(c.ewm(span=10,  adjust=False).mean().iloc[-1])
    ind["ema_20"]  = float(c.ewm(span=20,  adjust=False).mean().iloc[-1])
    ind["ema_80"]  = float(c.ewm(span=80,  adjust=False).mean().iloc[-1])

    # ── RSI + divergência ────────────────────────────────────────────────────
    delta = c.diff()
    gain  = delta.clip(lower=0).rolling(14).mean()
    loss  = (-delta.clip(upper=0)).rolling(14).mean()
    rs    = gain / loss.replace(0, np.nan)
    rsi_s = (100 - 100 / (1 + rs)).fillna(50)  # NaN (preço flat) → 50 neutro
    ind["rsi"]       = float(rsi_s.iloc[-1])
    ind["rsi_prev1"] = float(rsi_s.iloc[-2])
    ind["rsi_prev2"] = float(rsi_s.iloc[-3])
    ind["rsi_prev3"] = float(rsi_s.iloc[-4])

    # ── MACD ─────────────────────────────────────────────────────────────────
    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    macd  = ema12 - ema26
    sig   = macd.ewm(span=9, adjust=False).mean()
    ind["macd"]           = float(macd.iloc[-1])
    ind["macd_sig"]       = float(sig.iloc[-1])
    ind["macd_hist"]      = float((macd - sig).iloc[-1])
    ind["macd_prev_hist"] = float((macd - sig).iloc[-2])

    # ── Bollinger Bands ───────────────────────────────────────────────────────
    sma20 = c.rolling(20).mean()
    std20 = c.rolling(20).std()
    bb_u  = sma20 + 2 * std20
    bb_l  = sma20 - 2 * std20
    ind["bb_upper"] = float(bb_u.iloc[-1])
    ind["bb_lower"] = float(bb_l.iloc[-1])
    ind["bb_mid"]   = float(sma20.iloc[-1])
    ind["bb_pct"]   = float((c.iloc[-1] - ind["bb_lower"]) / (ind["bb_upper"] - ind["bb_lower"] + 1e-10))
    ind["bb_width"] = float((bb_u.iloc[-1] - bb_l.iloc[-1]) / (sma20.iloc[-1] + 1e-10))  # largura relativa

    # ── ATR + percentil de volatilidade ──────────────────────────────────────
    pc = c.shift()
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atr_series   = tr.rolling(14).mean()
    ind["atr"]   = float(atr_series.iloc[-1])
    # Percentil: onde a volatilidade atual se posiciona nos últimos 100 períodos
    atr_hist     = atr_series.dropna().values[-100:]
    if len(atr_hist) > 10:
        ind["atr_pct"] = float(np.sum(atr_hist <= ind["atr"]) / len(atr_hist))
    else:
        ind["atr_pct"] = 0.5

    # ── ADX — força da tendência ──────────────────────────────────────────────
    up_move   = h.diff()
    down_move = -l.diff()
    plus_dm   = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm  = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    atr14     = atr_series
    plus_di   = 100 * pd.Series(plus_dm,  index=c.index).rolling(14).mean() / (atr14 + 1e-10)
    minus_di  = 100 * pd.Series(minus_dm, index=c.index).rolling(14).mean() / (atr14 + 1e-10)
    dx        = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-10)
    adx       = dx.rolling(14).mean()
    ind["adx"]       = float(adx.iloc[-1])
    ind["plus_di"]   = float(plus_di.iloc[-1])
    ind["minus_di"]  = float(minus_di.iloc[-1])
    # ADX > 25 = trending, < 20 = ranging
    ind["trending"]  = 1.0 if ind["adx"] > 25 else (0.0 if ind["adx"] < 20 else 0.5)

    # ── Stochastic ────────────────────────────────────────────────────────────
    lo14 = l.rolling(14).min()
    hi14 = h.rolling(14).max()
    k    = 100 * (c - lo14) / (hi14 - lo14 + 1e-10)
    ind["stoch_k"] = float(k.iloc[-1])
    ind["stoch_d"] = float(k.rolling(3).mean().iloc[-1])

    # ── CCI — Commodity Channel Index ────────────────────────────────────────
    tp_cci   = (h + l + c) / 3
    sma_cci  = tp_cci.rolling(20).mean()
    mad      = tp_cci.rolling(20).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
    ind["cci"] = float(((tp_cci - sma_cci) / (0.015 * mad + 1e-10)).iloc[-1])

    # ── VWAP (aproximação intraday com dados disponíveis) ─────────────────────
    tp   = (h + l + c) / 3
    vwap = (tp * v).rolling(20).sum() / (v.rolling(20).sum() + 1e-10)
    ind["vwap"]        = float(vwap.iloc[-1])
    ind["price_vs_vwap"] = float((c.iloc[-1] - vwap.iloc[-1]) / (vwap.iloc[-1] + 1e-10))

    # ── OBV — On-Balance Volume ───────────────────────────────────────────────
    obv_vals = [0.0]
    for i in range(1, len(c)):
        if c.iloc[i] > c.iloc[i - 1]:
            obv_vals.append(obv_vals[-1] + float(v.iloc[i]))
        elif c.iloc[i] < c.iloc[i - 1]:
            obv_vals.append(obv_vals[-1] - float(v.iloc[i]))
        else:
            obv_vals.append(obv_vals[-1])
    obv = pd.Series(obv_vals, index=c.index)
    obv_ema = obv.ewm(span=10, adjust=False).mean()
    ind["obv_trend"] = 1.0 if obv.iloc[-1] > obv_ema.iloc[-1] else -1.0

    # ── Volume Delta (proxy: candle direcional × volume) ─────────────────────
    buy_vol  = v * (c - l) / (h - l + 1e-10)
    sell_vol = v * (h - c) / (h - l + 1e-10)
    delta_v  = buy_vol - sell_vol
    delta_ma = delta_v.rolling(10).mean()
    ind["vol_delta"]       = float(delta_v.iloc[-1])
    ind["vol_delta_trend"] = 1.0 if float(delta_ma.iloc[-1]) > 0 else -1.0
    ind["vol_ratio"]       = float(v.iloc[-1] / (v.rolling(20).mean().iloc[-1] + 1e-10))

    # ── Ichimoku Cloud ────────────────────────────────────────────────────────
    tenkan  = (h.rolling(9).max()  + l.rolling(9).min())  / 2
    kijun   = (h.rolling(26).max() + l.rolling(26).min()) / 2
    span_a  = ((tenkan + kijun) / 2)
    span_b  = (h.rolling(52).max() + l.rolling(52).min()) / 2
    ind["ich_tenkan"]  = float(tenkan.iloc[-1])
    ind["ich_kijun"]   = float(kijun.iloc[-1])
    ind["ich_span_a"]  = float(span_a.iloc[-1])
    ind["ich_span_b"]  = float(span_b.iloc[-1])
    price_now = float(c.iloc[-1])
    cloud_top = max(ind["ich_span_a"], ind["ich_span_b"])
    cloud_bot = min(ind["ich_span_a"], ind["ich_span_b"])
    ind["ich_above_cloud"] =  1.0 if price_now > cloud_top  else 0.0
    ind["ich_below_cloud"] =  1.0 if price_now < cloud_bot  else 0.0
    ind["ich_tk_cross"]    =  1.0 if ind["ich_tenkan"] > ind["ich_kijun"] else -1.0

    # ── Padrões de vela ───────────────────────────────────────────────────────
    curr_close = float(c.iloc[-1])
    curr_open  = float(o.iloc[-1])
    curr_high  = float(h.iloc[-1])
    curr_low   = float(l.iloc[-1])
    prev_close = float(c.iloc[-2])
    prev_open  = float(o.iloc[-2])
    body       = abs(curr_close - curr_open)
    range_     = curr_high - curr_low + 1e-10
    prev_body  = abs(prev_close - prev_open)
    upper_wick = curr_high - max(curr_close, curr_open)
    lower_wick = min(curr_close, curr_open) - curr_low
    ind["candle_body_pct"] = body / range_

    # Engulfing bullish: vela vermelha seguida de verde maior
    ind["engulf_bull"] = 1.0 if (prev_close < prev_open and curr_close > curr_open
                                  and body > prev_body * 1.1
                                  and curr_close > prev_open
                                  and curr_open < prev_close) else 0.0

    # Engulfing bearish: vela verde seguida de vermelha maior
    ind["engulf_bear"] = 1.0 if (prev_close > prev_open and curr_close < curr_open
                                  and body > prev_body * 1.1
                                  and curr_close < prev_open
                                  and curr_open > prev_close) else 0.0

    # Pinbar bullish (hammer): pavio inferior longo, corpo pequeno no topo
    ind["pinbar_bull"] = 1.0 if (lower_wick > body * 2 and lower_wick > upper_wick * 2
                                  and body / range_ < 0.4) else 0.0

    # Pinbar bearish (shooting star): pavio superior longo, corpo pequeno na base
    ind["pinbar_bear"] = 1.0 if (upper_wick > body * 2 and upper_wick > lower_wick * 2
                                  and body / range_ < 0.4) else 0.0

    # Doji: corpo muito pequeno = indecisão
    ind["doji"] = 1.0 if body / range_ < 0.1 else 0.0

    # ── SMC — Wick Sweep ──────────────────────────────────────────────────────
    last5_low  = l.iloc[-6:-1].min()
    last5_high = h.iloc[-6:-1].max()
    ind["smc_bull_wick"] = 1.0 if (curr_low < last5_low and curr_close > last5_low
                                    and curr_close > curr_open) else 0.0
    ind["smc_bear_wick"] = 1.0 if (curr_high > last5_high and curr_close < last5_high
                                    and curr_close < curr_open) else 0.0

    # ── Momentum de preço ─────────────────────────────────────────────────────
    ind["momentum_5"]  = float((c.iloc[-1] / c.iloc[-6]  - 1) * 100)
    ind["momentum_10"] = float((c.iloc[-1] / c.iloc[-11] - 1) * 100)

    # ── Break of Structure (BOS) ──────────────────────────────────────────────
    # BOS bearish: fechamento abaixo do mínimo das últimas 5 velas (estrutura rompida para baixo)
    swing_low_5  = l.iloc[-7:-2].min()
    swing_high_5 = h.iloc[-7:-2].max()
    ind["bos_bear"] = 1.0 if curr_close < swing_low_5  else 0.0
    ind["bos_bull"] = 1.0 if curr_close > swing_high_5 else 0.0

    # ── Order Block Detection ─────────────────────────────────────────────────
    # Bearish OB: última vela ALTA (bullish) antes de uma queda forte
    # = zona de oferta onde instituições venderam → resistência quando preço volta
    ind["at_bearish_ob"] = 0.0
    ind["at_bullish_ob"] = 0.0
    lookback_ob = min(20, len(df) - 3)
    for i in range(2, lookback_ob):
        oc   = df["close"].iloc[-i]
        oo   = df["open"].iloc[-i]
        oh   = df["high"].iloc[-i]
        nxt_c = df["close"].iloc[-(i - 1)]
        nxt_o = df["open"].iloc[-(i - 1)]
        # OB bearish: vela bullish seguida de vela bearish forte (>= 0.5× ATR)
        if oc > oo and (nxt_o - nxt_c) >= ind["atr"] * 0.5:
            ob_top = oh
            ob_bot = oo
            if ob_bot <= curr_close <= ob_top:
                ind["at_bearish_ob"] = 1.0
                break
        # OB bullish: vela bearish seguida de vela bullish forte
        ol = df["low"].iloc[-i]
        if oo > oc and (nxt_c - nxt_o) >= ind["atr"] * 0.5:
            ob_top = oo
            ob_bot = ol
            if ob_bot <= curr_close <= ob_top:
                ind["at_bullish_ob"] = 1.0
                break

    ind["price"]       = curr_close
    ind["price_low"]   = curr_low
    ind["price_high"]  = curr_high
    return ind


def detect_sr_levels(df: pd.DataFrame,
                     lookback: int = 100,
                     window: int = 5) -> Tuple[List[float], List[float]]:
    recent = df.tail(lookback)
    highs  = recent["high"].values
    lows   = recent["low"].values
    resistances: List[float] = []
    supports:    List[float] = []

    for i in range(window, len(highs) - window):
        if highs[i] >= max(highs[i - window: i + window + 1]):
            resistances.append(float(highs[i]))
        if lows[i] <= min(lows[i - window: i + window + 1]):
            supports.append(float(lows[i]))

    def cluster(levels: List[float]) -> List[float]:
        if not levels:
            return []
        levels = sorted(set(levels))
        clustered = [levels[0]]
        for lv in levels[1:]:
            if abs(lv - clustered[-1]) / (clustered[-1] + 1e-10) > 0.003:
                clustered.append(lv)
        return clustered

    return cluster(resistances), cluster(supports)


# ============================================================================
# ANÁLISE EM DUAS CAMADAS
# ============================================================================

class TwoLayerAnalyzer:

    @staticmethod
    def _trend_signals(ind: Dict) -> List[Tuple[str, int]]:
        p = ind["price"]
        signals = []

        # ── EMA Stack ────────────────────────────────────────────────────────
        signals.append(("EMA10>20",  1 if ind["ema_10"] > ind["ema_20"] else -1))
        signals.append(("EMA20>80",  1 if ind["ema_20"] > ind["ema_80"] else -1))
        signals.append(("Price>EMA80", 1 if p > ind["ema_80"] else -1))

        # ── RSI ───────────────────────────────────────────────────────────────
        rsi = ind["rsi"]
        if rsi > 55:   signals.append(("RSI>55", 1))
        elif rsi < 45: signals.append(("RSI<45", -1))
        else:          signals.append(("RSI_neutral", 0))

        # ── MACD ─────────────────────────────────────────────────────────────
        signals.append(("MACD>sig", 1 if ind["macd"] > ind["macd_sig"] else -1))

        # ── Bollinger ────────────────────────────────────────────────────────
        bp = ind["bb_pct"]
        if bp > 0.55:   signals.append(("BB_upper", 1))
        elif bp < 0.45: signals.append(("BB_lower", -1))
        else:           signals.append(("BB_mid",   0))

        # ── ADX — força da tendência (peso 2) ─────────────────────────────────
        adx = ind.get("adx", 0)
        if adx > 25:
            # Tendência forte — +DI vs -DI define direção
            if ind.get("plus_di", 0) > ind.get("minus_di", 0):
                signals.append(("ADX_bull_strong", 2))
            else:
                signals.append(("ADX_bear_strong", -2))
        elif adx < 20:
            signals.append(("ADX_ranging", 0))  # mercado lateral

        # ── Ichimoku Cloud (peso 2) ───────────────────────────────────────────
        if ind.get("ich_above_cloud"):
            signals.append(("ICH_above_cloud", 2))
        elif ind.get("ich_below_cloud"):
            signals.append(("ICH_below_cloud", -2))
        signals.append(("ICH_tk", 1 if ind.get("ich_tk_cross", 0) > 0 else -1))

        # ── VWAP ─────────────────────────────────────────────────────────────
        pvwap = ind.get("price_vs_vwap", 0)
        if pvwap > 0.002:   signals.append(("VWAP_above", 1))
        elif pvwap < -0.002: signals.append(("VWAP_below", -1))
        else:                signals.append(("VWAP_neutral", 0))

        # ── OBV ──────────────────────────────────────────────────────────────
        signals.append(("OBV", 1 if ind.get("obv_trend", 0) > 0 else -1))

        # ── Volume Delta ─────────────────────────────────────────────────────
        signals.append(("VolDelta", 1 if ind.get("vol_delta_trend", 0) > 0 else -1))

        return signals

    def score_trend(self, ind: Dict) -> Tuple[Direction, float, int, int]:
        signals = self._trend_signals(ind)
        total   = len(signals)
        bullish = sum(1 for _, v in signals if v > 0)
        bearish = sum(1 for _, v in signals if v < 0)
        bull_pct = bullish / total
        bear_pct = bearish / total
        if bull_pct >= 0.57:
            return Direction.LONG,  bull_pct * 100, bullish, total
        elif bear_pct >= 0.57:
            return Direction.SHORT, bear_pct * 100, bearish, total
        return Direction.NONE, 50.0, max(bullish, bearish), total

    async def get_trend_bias(self, api: BitgetPerpetualAPI, symbol: str,
                              timeframes: List[str]) -> TrendBias:
        async def fetch(tf: str):
            klines = await api.get_klines(symbol, tf, limit=250)
            df = build_df(klines)
            return (tf, calc_indicators(df)) if df is not None else (tf, None)

        results = await asyncio.gather(*[fetch(tf) for tf in timeframes],
                                        return_exceptions=True)
        bull_votes = bear_votes = total_votes = 0
        summaries = []
        for item in results:
            if isinstance(item, Exception):
                continue
            tf, ind = item
            if ind is None:
                continue
            direction, score, conf, tot = self.score_trend(ind)
            total_votes += 1
            if direction == Direction.LONG:
                bull_votes += 1
                summaries.append(f"[{tf}] BULL {score:.0f}%")
            elif direction == Direction.SHORT:
                bear_votes += 1
                summaries.append(f"[{tf}] BEAR {score:.0f}%")
            else:
                summaries.append(f"[{tf}] LATERAL")

        if total_votes == 0:
            return TrendBias(Direction.NONE, 50.0, 0, 0, "Sem dados")

        bull_pct = bull_votes / total_votes
        bear_pct = bear_votes / total_votes
        if bull_pct >= 0.60:
            direction, confluence, score = Direction.LONG,  bull_votes, bull_pct * 100
        elif bear_pct >= 0.60:
            direction, confluence, score = Direction.SHORT, bear_votes, bear_pct * 100
        else:
            direction, confluence, score = Direction.NONE, max(bull_votes, bear_votes), 50.0

        return TrendBias(direction, score, confluence, total_votes,
                         " | ".join(summaries))

    @staticmethod
    def _volatility_ok(ind: Dict) -> bool:
        """Filtra mercados com volatilidade muito baixa ou muito alta."""
        pct = ind.get("atr_pct", 0.5)
        return 0.10 < pct  # evita apenas squeeze extremo — sem limite superior

    @staticmethod
    def _entry_signals(ind: Dict, bias: Direction) -> List[Tuple[str, int]]:
        p   = ind["price"]
        rsi = ind["rsi"]
        signals = []

        # ── RSI Exaustão (peso 2) ─────────────────────────────────────────────
        if rsi < 30:    signals.append(("RSI_oversold_ext", 2))
        elif rsi < 38:  signals.append(("RSI_oversold", 1))
        elif rsi > 70:  signals.append(("RSI_overbought_ext", -2))
        elif rsi > 62:  signals.append(("RSI_overbought", -1))
        elif 42 <= rsi <= 55 and bias == Direction.LONG:
            signals.append(("RSI_zona_long", 1))
        elif 45 <= rsi <= 58 and bias == Direction.SHORT:
            signals.append(("RSI_zona_short", -1))
        else:
            signals.append(("RSI_neutro", 0))

        # RSI divergência (peso 2)
        rsi_p1, rsi_p2 = ind.get("rsi_prev1", rsi), ind.get("rsi_prev2", rsi)
        if rsi < 45 and rsi > rsi_p1 and rsi_p1 > rsi_p2 and bias == Direction.LONG:
            signals.append(("RSI_div_bull", 2))
        elif rsi > 55 and rsi < rsi_p1 and rsi_p1 < rsi_p2 and bias == Direction.SHORT:
            signals.append(("RSI_div_bear", -2))

        # ── CCI (peso 1) ──────────────────────────────────────────────────────
        cci = ind.get("cci", 0)
        if cci < -100 and bias == Direction.LONG:   signals.append(("CCI_oversold", 1))
        elif cci > 100 and bias == Direction.SHORT:  signals.append(("CCI_overbought", -1))
        elif cci > 0 and bias == Direction.LONG:     signals.append(("CCI_pos", 1))
        elif cci < 0 and bias == Direction.SHORT:    signals.append(("CCI_neg", -1))
        else:                                         signals.append(("CCI_neutro", 0))

        # ── Break of Structure — peso 3 (confirmação mais forte) ────────────
        if ind.get("bos_bear") and bias == Direction.SHORT:
            signals.append(("BOS_bear", 3))
        elif ind.get("bos_bull") and bias == Direction.LONG:
            signals.append(("BOS_bull", 3))
        else:
            signals.append(("BOS_neutro", 0))

        # ── Order Block — peso 3 (zona institucional) ─────────────────────
        if ind.get("at_bearish_ob") and bias == Direction.SHORT:
            signals.append(("OB_bearish", 3))
        elif ind.get("at_bullish_ob") and bias == Direction.LONG:
            signals.append(("OB_bullish", 3))
        else:
            signals.append(("OB_neutro", 0))

        # ── SMC Wick Sweep (peso 2) ───────────────────────────────────────────
        if ind.get("smc_bull_wick") and ind.get("candle_body_pct", 0) > 0.4:
            signals.append(("SMC_bull", 2))
        elif ind.get("smc_bear_wick") and ind.get("candle_body_pct", 0) > 0.4:
            signals.append(("SMC_bear", -2))
        if ind["vol_ratio"] > 1.5 and ind.get("smc_bull_wick"):
            signals.append(("SMC_vol_bull", 2))
        elif ind["vol_ratio"] > 1.5 and ind.get("smc_bear_wick"):
            signals.append(("SMC_vol_bear", -2))

        # ── Padrões de vela (peso 2) ──────────────────────────────────────────
        if ind.get("engulf_bull") and bias == Direction.LONG:
            signals.append(("Engulf_bull", 2))
        if ind.get("engulf_bear") and bias == Direction.SHORT:
            signals.append(("Engulf_bear", -2))
        if ind.get("pinbar_bull") and bias == Direction.LONG:
            signals.append(("Pinbar_bull", 2))
        if ind.get("pinbar_bear") and bias == Direction.SHORT:
            signals.append(("Pinbar_bear", -2))
        if ind.get("doji"):
            signals.append(("Doji_indecision", 0))

        # ── MACD (peso 1) ─────────────────────────────────────────────────────
        if ind["macd_hist"] > 0 and ind["macd_prev_hist"] <= 0:
            signals.append(("MACD_cross_up", 1))
        elif ind["macd_hist"] < 0 and ind["macd_prev_hist"] >= 0:
            signals.append(("MACD_cross_down", -1))
        elif ind["macd_hist"] > 0: signals.append(("MACD_pos", 1))
        else:                       signals.append(("MACD_neg", -1))

        # ── Stochastic (peso 1) ───────────────────────────────────────────────
        k, d = ind["stoch_k"], ind["stoch_d"]
        if k < 20 and d < 20:       signals.append(("Stoch_oversold", 1))
        elif k > 80 and d > 80:     signals.append(("Stoch_overbought", -1))
        elif k > d and k < 55:      signals.append(("Stoch_rising", 1))
        elif k < d and k > 45:      signals.append(("Stoch_falling", -1))
        else:                        signals.append(("Stoch_neutro", 0))

        # ── Bollinger Bands (peso 1) ──────────────────────────────────────────
        bp = ind["bb_pct"]
        if bp < 0.10:                               signals.append(("BB_abaixo", 1))
        elif bp > 0.90:                             signals.append(("BB_acima", -1))
        elif bp < 0.25 and bias == Direction.LONG:  signals.append(("BB_low_long", 1))
        elif bp > 0.75 and bias == Direction.SHORT: signals.append(("BB_high_short", -1))
        else:                                        signals.append(("BB_neutro", 0))

        # ── EMA curta (peso 1) ────────────────────────────────────────────────
        signals.append(("EMA10", 1 if p > ind["ema_10"] else -1))
        signals.append(("EMA20", 1 if p > ind["ema_20"] else -1))

        # ── VWAP (peso 1) ─────────────────────────────────────────────────────
        pvwap = ind.get("price_vs_vwap", 0)
        if pvwap > 0.001 and bias == Direction.LONG:    signals.append(("VWAP_long", 1))
        elif pvwap < -0.001 and bias == Direction.SHORT: signals.append(("VWAP_short", -1))
        else:                                             signals.append(("VWAP_neutro", 0))

        # ── OBV (peso 1) ──────────────────────────────────────────────────────
        obv = ind.get("obv_trend", 0)
        signals.append(("OBV", 1 if obv > 0 and bias == Direction.LONG
                         else (-1 if obv < 0 and bias == Direction.SHORT else 0)))

        # ── Volume Delta (peso 1) ─────────────────────────────────────────────
        vd = ind.get("vol_delta_trend", 0)
        signals.append(("VolDelta", 1 if vd > 0 and bias == Direction.LONG
                         else (-1 if vd < 0 and bias == Direction.SHORT else 0)))

        # ── Momentum (peso 1) ─────────────────────────────────────────────────
        mom5 = ind.get("momentum_5", 0)
        if mom5 > 0.3 and bias == Direction.LONG:    signals.append(("Mom5_bull", 1))
        elif mom5 < -0.3 and bias == Direction.SHORT: signals.append(("Mom5_bear", -1))
        else:                                          signals.append(("Mom5_neutro", 0))

        # ── Volume Spike (peso 1) ─────────────────────────────────────────────
        if ind["vol_ratio"] > 1.8:
            signals.append(("Vol_spike", 1 if bias == Direction.LONG else -1))
        elif ind["vol_ratio"] > 1.3:
            signals.append(("Vol_acima", 1 if bias == Direction.LONG else -1))
        else:
            signals.append(("Vol_fraco", 0))

        return signals

    async def get_entry_signal(self, api: BitgetPerpetualAPI, symbol: str,
                                timeframes: List[str],
                                bias: Direction) -> EntrySignal:
        async def fetch(tf: str):
            klines = await api.get_klines(symbol, tf, limit=200)
            df = build_df(klines)
            return (tf, calc_indicators(df)) if df is not None else (tf, None)

        results = await asyncio.gather(*[fetch(tf) for tf in timeframes],
                                        return_exceptions=True)
        target     = 1 if bias == Direction.LONG else -1
        total_peso = agree_peso = 0
        primary_ind = None
        summaries   = []

        for item in results:
            if isinstance(item, Exception):
                continue
            tf, ind = item
            if ind is None:
                continue
            if primary_ind is None:
                primary_ind = ind
            sigs      = self._entry_signals(ind, bias)
            tf_agree  = sum(abs(v) for _, v in sigs if (v > 0) == (target > 0) and v != 0)
            tf_total  = sum(abs(v) for _, v in sigs if v != 0)
            total_peso += tf_total
            agree_peso += tf_agree
            strong = [n for n, v in sigs if abs(v) == 2 and (v > 0) == (target > 0)]
            pct = tf_agree / tf_total * 100 if tf_total else 0
            tag = f"★{','.join(strong)}" if strong else ""
            summaries.append(f"[{tf}] {pct:.0f}% {tag}".strip())

        if primary_ind is None or total_peso == 0:
            return EntrySignal(Direction.NONE, 0, 0, 0, 0, 0, "Sem dados")

        confluence_pct = agree_peso / total_peso
        score          = confluence_pct * 100
        direction      = bias if confluence_pct >= 0.60 else Direction.NONE

        return EntrySignal(
            direction=direction, score=score,
            confluence=int(agree_peso), total_signals=int(total_peso),
            price=primary_ind["price"], atr=primary_ind["atr"],
            summary=" | ".join(summaries),
        )

    async def get_current_rsi(self, api: BitgetPerpetualAPI, symbol: str,
                               timeframe: str = "5m") -> float:
        """Retorna RSI atual para decisões de saída."""
        klines = await api.get_klines(symbol, timeframe, limit=100)
        df = build_df(klines)
        if df is None:
            return 50.0
        return calc_indicators(df)["rsi"]

    async def get_current_price_and_indicators(self, api: BitgetPerpetualAPI,
                                                symbol: str,
                                                timeframe: str = "5m") -> Optional[Dict]:
        klines = await api.get_klines(symbol, timeframe, limit=200)
        df = build_df(klines)
        if df is None:
            return None
        ind = calc_indicators(df)
        res, sup = detect_sr_levels(df)
        ind["resistances"] = res
        ind["supports"]    = sup
        return ind


# ============================================================================
# GERENCIADOR DE RISCO
# ============================================================================

class RiskManager:

    TAKER_FEE    = 0.0006
    MIN_CONTRACTS = 1

    def __init__(self, balance_dot: float, config: StrategyConfig):
        self.balance      = balance_dot
        self.peak_balance = balance_dot
        self.daily_start  = balance_dot
        self.cfg          = config
        self.win_count    = 0
        self.loss_count   = 0

    def kelly_fraction(self, rr: float) -> float:
        total = self.win_count + self.loss_count
        if total < 10:
            return self.cfg.risk_percent
        p     = self.win_count / total
        q     = 1 - p
        b     = rr
        kelly = (p * b - q) / b
        kelly = max(0, kelly)
        return min(kelly * 0.25, self.cfg.risk_percent * 2)

    def calc_levels(self, price: float, atr: float,
                    direction: Direction,
                    resistances: List[float] = None,
                    supports: List[float]    = None
                    ) -> Tuple[float, float, float, float, float]:
        """
        Retorna (entry, tp1, tp2, tp3, sl).
        tp1 = primeiro alvo ATR
        tp2 = resistência/suporte mais próximo acima/abaixo
        tp3 = RSI extremo estimado (2x ATR ou próximo nível mais distante)
        """
        sl_dist = atr * self.cfg.sl_atr_mult
        tp1_dist = atr * self.cfg.tp_atr_mult

        fee_cost    = price * self.TAKER_FEE * 2
        min_tp_dist = fee_cost * 3
        tp1_dist    = max(tp1_dist, min_tp_dist)

        if direction == Direction.LONG:
            sl  = price - sl_dist
            tp1 = price + tp1_dist
            # tp2: próxima resistência acima do preço
            tp2 = tp1
            if resistances:
                above = [r for r in resistances if r > price * 1.002]
                if above:
                    tp2 = above[0]
            tp2 = max(tp2, tp1)
            # tp3: resistência ainda mais distante ou 2×ATR
            tp3 = price + atr * 2.5
            if resistances:
                far_above = [r for r in resistances if r > tp2 * 1.003]
                if far_above:
                    tp3 = far_above[0]
            tp3 = max(tp3, tp2 * 1.002)
        else:
            sl  = price + sl_dist
            tp1 = price - tp1_dist
            tp2 = tp1
            if supports:
                below = [s for s in supports if s < price * 0.998]
                if below:
                    tp2 = below[-1]
            tp2 = min(tp2, tp1)
            tp3 = price - atr * 2.5
            if supports:
                far_below = [s for s in supports if s < tp2 * 0.997]
                if far_below:
                    tp3 = far_below[-1]
            tp3 = min(tp3, tp2 * 0.998)

        return price, tp1, tp2, tp3, sl

    def calc_trailing_sl(self, current_price: float, atr: float,
                          direction: Direction) -> float:
        dist = atr * self.cfg.trailing_distance_mult
        if direction == Direction.LONG:
            return current_price - dist
        return current_price + dist

    def calc_qty(self, entry: float, sl: float, rr: float,
                  size_ratio: float = 1.0) -> float:
        price_risk = abs(entry - sl)
        if price_risk < 1e-8:
            return 0.0
        risk_pct_qty = (self.balance * self.cfg.risk_percent * size_ratio) / price_risk * self.cfg.leverage
        kelly_f      = self.kelly_fraction(rr)
        kelly_qty    = (self.balance * kelly_f * size_ratio) / price_risk * self.cfg.leverage
        qty          = min(risk_pct_qty, kelly_qty)
        max_risk_qty = (self.balance * 0.02) / price_risk * self.cfg.leverage
        qty          = min(qty, max_risk_qty)
        qty          = max(qty, self.MIN_CONTRACTS)
        # Entrada inicial: máximo 10% do saldo como margem
        max_by_bal   = self.balance * 0.10 * self.cfg.leverage / entry
        qty          = min(qty, max_by_bal)
        return int(qty)

    def liquidation_price(self, entry: float, direction: Direction) -> float:
        lev        = self.cfg.leverage
        margin_rate = 1 / lev
        maint      = 0.005
        if direction == Direction.LONG:
            return entry * (1 - margin_rate + maint)
        return entry * (1 + margin_rate - maint)

    def sl_safe_from_liq(self, sl: float, liq: float, direction: Direction) -> bool:
        return abs(sl - liq) / liq >= 0.15

    def daily_drawdown_ok(self) -> bool:
        loss_pct = (self.daily_start - self.balance) / self.daily_start
        return loss_pct < 0.05

    def reset_daily(self):
        self.daily_start = self.balance

    def record_result(self, won: bool, pnl_dot: float):
        if won:
            self.win_count += 1
        else:
            self.loss_count += 1
        self.balance      += pnl_dot
        self.peak_balance  = max(self.peak_balance, self.balance)

    def print_risk_report(self):
        total = self.win_count + self.loss_count
        wr    = self.win_count / total * 100 if total else 0
        dd    = (self.peak_balance - self.balance) / self.peak_balance * 100
        kelly = self.kelly_fraction(1.43)
        logger.info(f"\n{'─'*55}")
        logger.info(f"  RISCO  |  Saldo: {self.balance:.4f} (sincronizado da API)")
        logger.info(f"         |  Win rate: {wr:.1f}%  ({self.win_count}W/{self.loss_count}L)")
        logger.info(f"         |  Drawdown atual: {dd:.2f}%")
        logger.info(f"         |  Kelly frac: {kelly*100:.2f}%")
        logger.info(f"         |  Drawdown OK: {'✅' if self.daily_drawdown_ok() else '🛑 TRAVADO'}")
        logger.info(f"{'─'*55}")


# ============================================================================
# ESTATÍSTICAS
# ============================================================================

class SimulationStats:

    def __init__(self):
        self.trades: List[SimulatedTrade] = []

    def record(self, t: SimulatedTrade):
        self.trades.append(t)

    def print_report(self):
        closed = [t for t in self.trades if t.result != "open"]
        wins   = [t for t in closed if t.result == "win"]
        losses = [t for t in closed if t.result == "loss"]
        open_  = [t for t in self.trades if t.result == "open"]
        total  = len(closed)
        wr     = len(wins) / total * 100 if total else 0
        avg_win  = np.mean([t.pnl_pct for t in wins])  if wins   else 0
        avg_loss = np.mean([t.pnl_pct for t in losses]) if losses else 0
        exp = (wr / 100 * avg_win) + ((1 - wr / 100) * avg_loss)

        logger.info(f"\n{'='*65}")
        logger.info(f"  RELATÓRIO")
        logger.info(f"{'='*65}")
        logger.info(f"  Total sinais: {len(self.trades)}  |  Fechados: {total}  |  Abertos: {len(open_)}")
        logger.info(f"  Win rate    : {wr:.1f}%  |  Expectância: {exp:.3f}%")
        logger.info(f"  Lucro médio : +{avg_win:.3f}%  |  Perda média: {avg_loss:.3f}%")
        verdict = "✅ PROMISSORA" if wr >= 55 and exp > 0 else "⚠️ AJUSTAR"
        logger.info(f"  Veredicto   : {verdict}")
        logger.info(f"{'='*65}\n")
        if self.trades:
            logger.info("  Últimos 10:")
            for t in self.trades[-10:]:
                icon = {"win": "✅", "loss": "❌", "open": "⏳"}.get(t.result, "?")
                logger.info(f"  {icon} {t.symbol:10s} {t.direction.upper():5s} | conf {t.confidence:.0f}% | pnl {t.pnl_pct:+.3f}%")


# ============================================================================
# AGENTE PRINCIPAL
# ============================================================================

class BitgetTradingAgent:

    TREND_TFS  = ["1H", "4H", "1D"]
    ENTRY_TFS  = ["5m", "15m"]
    MARKET_REF = "BTCUSD"

    def __init__(
        self,
        api_key: str, api_secret: str, passphrase: str,
        account_balance: float,
        symbols: List[str],
        config: StrategyConfig,
        product_type: str = "COIN-FUTURES",
        check_interval: int = 30,
        testnet: bool = True,
    ):
        self.api      = BitgetPerpetualAPI(api_key, api_secret, passphrase, product_type)
        self.analyzer = TwoLayerAnalyzer()
        self.risk     = RiskManager(account_balance, config)
        self.cfg      = config
        self.symbols  = symbols
        self.interval = check_interval
        self.testnet  = testnet
        self.sim      = SimulationStats()

        # Posições abertas com gestão ativa
        self.open_positions: Dict[str, OpenPosition] = {}

        # Saldos reais lidos da Bitget — atualizados a cada 10 ciclos
        self.live_balances: Dict[str, float] = {}

        # Rastreia tendência recente para reentradas
        self.last_trend: Dict[str, Direction] = {}
        self.last_close_cycle: Dict[str, int] = {}
        self.last_close_time: Dict[str, datetime] = {}
        self.consecutive_losses: Dict[str, int] = {}
        self.daily_loss_pct: Dict[str, float] = {}
        self.last_profitable: Dict[str, dict] = {}  # re-entrada Fibonacci
        self.iteration = 0

        logger.info(f"🤖 Agente v4 | {'TESTNET/SIM' if testnet else '⚠️ LIVE'} | {product_type}")
        logger.info(f"   Ativos: {', '.join(symbols)}  |  Filtro macro: {self.MARKET_REF}")
        logger.info(f"   Tendência: {self.TREND_TFS}  |  Entrada: {self.ENTRY_TFS}")
        logger.info(f"   Ciclo: {check_interval}s | Leverage: {config.leverage}x | Risco: {config.risk_percent*100:.1f}%/trade")
        logger.info(f"   Pirâmide: até {config.max_pyramid_entries}x | Trailing: >{config.trailing_start_mult}ATR")
        logger.info(f"   TP parcial: {config.partial_tp1_pct*100:.0f}%+{config.partial_tp2_pct*100:.0f}% | RSI saída: >{config.rsi_long_exit}/{config.rsi_short_exit}<")

    # ── Análise de mercado ────────────────────────────────────────────────────

    async def get_market_bias(self) -> Tuple[Direction, bool]:
        """Retorna (direction, btc_lateral).
        Estratégia de reversão: BTC sobrecomprado (RSI ≥ 80) → SHORT nas altcoins.
        BTC sobrevendido (RSI ≤ 20) → LONG nas altcoins.
        BTC neutro (RSI entre 20-80) → cada altcoin usa sua própria estrutura."""
        os_thresh = self.cfg.rsi_cascade_threshold   # 20.0
        ob_thresh = 100.0 - os_thresh                # 80.0
        tfs        = ["1D", "4H", "1H"]
        long_hits  = 0  # TFs com RSI ≤ 20
        short_hits = 0  # TFs com RSI ≥ 80
        rsi_parts  = []

        for tf in tfs:
            ind = await self.analyzer.get_current_price_and_indicators(self.api, self.MARKET_REF, tf)
            rsi = ind["rsi"] if ind else 50.0
            if rsi <= os_thresh:
                long_hits += 1
                rsi_parts.append(f"{tf}:{rsi:.0f}↑")
            elif rsi >= ob_thresh:
                short_hits += 1
                rsi_parts.append(f"{tf}:{rsi:.0f}↓")
            else:
                rsi_parts.append(f"{tf}:{rsi:.0f}")

        rsi_summary = " | ".join(rsi_parts)

        if long_hits >= 1:
            direction   = Direction.LONG
            btc_lateral = False
            logger.info(f"   📊 BTC RSI: SOBREVENDIDO → LONG ({long_hits} TF(s)) [{rsi_summary}]")
        elif short_hits >= 1:
            direction   = Direction.SHORT
            btc_lateral = False
            logger.info(f"   📊 BTC RSI: SOBRECOMPRADO → SHORT ({short_hits} TF(s)) [{rsi_summary}]")
        else:
            direction   = Direction.NONE
            btc_lateral = True
            logger.info(f"   📊 BTC RSI: NEUTRO → altcoins usam tendência própria [{rsi_summary}]")

        return direction, btc_lateral

    async def analyze_symbol(self, symbol: str,
                              market_bias: Direction = Direction.NONE,
                              btc_lateral: bool = False) -> Optional[TradeSignal]:
        try:
            # ── Não abre nova posição se já existe (monitor cuida do rastreio) ──
            if symbol in self.open_positions:
                return None

            # ── Fibonacci re-entry (verificação prioritária) ───────────────────
            fib_dir        = await self._fib_reentry_signal(symbol)
            is_fib_reentry = fib_dir is not None

            # ── Busca indicadores 15m para filtros antecipados ────────────────
            ind = await self.analyzer.get_current_price_and_indicators(
                self.api, symbol, "15m"
            )

            # Filtro de volatilidade — não opera em squeeze extremo ou caos
            if ind and not self.analyzer._volatility_ok(ind):
                logger.info(f"   ⏭ {symbol}: volatilidade fora do range ideal (ATR pct={ind.get('atr_pct',0):.2f})")
                return None

            # Filtro de regime — ADX muito baixo = lateral, evita
            if ind and ind.get("adx", 25) < 18:
                logger.info(f"   ⏭ {symbol}: mercado lateral (ADX={ind.get('adx',0):.1f})")
                return None

            # ── Funding Rate — bias de direção ────────────────────────────────
            funding = await self.api.get_funding_rate(symbol)
            funding_bias = Direction.NONE
            if abs(funding) > 0.0003:
                funding_bias = Direction.SHORT if funding > 0 else Direction.LONG
                logger.info(f"   💰 Funding {symbol}: {funding*100:.4f}% → bias {funding_bias.value}")

            # ── Direção efetiva ────────────────────────────────────────────────
            if is_fib_reentry:
                # Re-entrada Fibonacci — direção já determinada, pula cascade
                effective_bias = fib_dir
                self.last_profitable[symbol]["reentry_used"] = True
                logger.info(f"   ♻️ {symbol}: re-entrada Fibonacci {effective_bias.value.upper()} — cascade ignorada")
                cascade_score, cascade_tfs = 0, 0
            else:
                # Reversão: BTC RSI extremo define a direção; BTC neutro → RSI da altcoin decide
                if btc_lateral:
                    long_score, long_tfs, _ = await self._check_rsi_cascade(symbol, Direction.LONG)
                    short_score, short_tfs, _ = await self._check_rsi_cascade(symbol, Direction.SHORT)
                    if long_tfs >= self.cfg.rsi_cascade_min_tfs and long_tfs >= short_tfs:
                        effective_bias = Direction.LONG
                    elif short_tfs >= self.cfg.rsi_cascade_min_tfs:
                        effective_bias = Direction.SHORT
                    else:
                        return None
                    trend = await self.analyzer.get_trend_bias(self.api, symbol, self.TREND_TFS)
                    logger.info(
                        f"   🔄 {symbol}: BTC neutro → RSI próprio {effective_bias.value.upper()} "
                        f"({long_tfs} TFs LONG | {short_tfs} TFs SHORT)"
                    )
                else:
                    effective_bias = market_bias
                    # busca tendência para scoring de confiança (não bloqueia)
                    trend = await self.analyzer.get_trend_bias(self.api, symbol, self.TREND_TFS)

                # ── RSI Cascata ────────────────────────────────────────────────
                cascade_score, cascade_tfs, cascade_summary = await self._check_rsi_cascade(
                    symbol, effective_bias
                )
                if cascade_tfs < self.cfg.rsi_cascade_min_tfs:
                    logger.info(
                        f"   ❌ {symbol}: RSI cascata insuficiente "
                        f"({cascade_tfs}/{self.cfg.rsi_cascade_min_tfs} TFs) [{cascade_summary}]"
                    )
                    return None
                logger.info(
                    f"   ✅ {symbol}: RSI cascata OK "
                    f"({cascade_tfs} TFs, score={cascade_score}) [{cascade_summary}]"
                )

            # ── Trigger 5m: EMA 10/20 alinhadas + RSI com momentum ───────────────
            # O 5m não exige RSI no extremo — quem confirma exaustão é 4H/1D.
            # O 5m apenas confirma que o preço começou a mover na direção certa.
            ind_5m_trig = await self.analyzer.get_current_price_and_indicators(
                self.api, symbol, "5m"
            )
            if ind_5m_trig:
                price_5m   = ind_5m_trig["price"]
                ema10_5m   = ind_5m_trig["ema_10"]
                ema20_5m   = ind_5m_trig["ema_20"]
                rsi_5m_val = ind_5m_trig["rsi"]
                rsi_5m_p1  = ind_5m_trig.get("rsi_prev1", rsi_5m_val)
                rsi_5m_p2  = ind_5m_trig.get("rsi_prev2", rsi_5m_p1)

                if effective_bias == Direction.LONG:
                    # Primeira virada: RSI estava ≤30 e agora subiu (você faria na mão aqui)
                    virou     = (rsi_5m_p1 <= 32 or rsi_5m_p2 <= 32) and rsi_5m_val > rsi_5m_p1
                    # Ou já saiu bem do oversold
                    ja_saiu   = rsi_5m_val > 38
                    trigger_ok = virou or ja_saiu
                    modo = "virada" if virou else "saída oversold"
                else:
                    # Primeira virada: RSI estava ≥70 e agora caiu (você faria na mão aqui)
                    virou     = (rsi_5m_p1 >= 68 or rsi_5m_p2 >= 68) and rsi_5m_val < rsi_5m_p1
                    # Ou já saiu bem do overbought
                    ja_saiu   = rsi_5m_val < 62
                    trigger_ok = virou or ja_saiu
                    modo = "virada" if virou else "saída overbought"
            else:
                trigger_ok = False
                rsi_5m_val = 50.0
                modo = "sem dados"

            if not trigger_ok:
                logger.info(
                    f"   ⏳ {symbol}: 5m aguardando virada "
                    f"(RSI={rsi_5m_val:.1f} prev={rsi_5m_p1:.1f})"
                )
                return None
            logger.info(f"   🔫 {symbol}: trigger 5m OK [{modo}] RSI={rsi_5m_val:.1f}←{rsi_5m_p1:.1f}")

            # Funding contra a direção = penaliza, mas não bloqueia
            funding_penalty = 0.05 if (funding_bias != Direction.NONE and
                                        funding_bias != effective_bias) else 0.0

            entry = await self.analyzer.get_entry_signal(
                self.api, symbol, self.ENTRY_TFS, effective_bias
            )
            if entry.direction != effective_bias:
                return None

            trend_ok = trend.confluence / trend.total_signals >= self.cfg.min_trend_confluence
            entry_ok = entry.confluence / entry.total_signals >= self.cfg.min_entry_confluence
            overall  = (trend.score * 0.40 + entry.score * 0.60) / 100 - funding_penalty

            if not trend_ok or not entry_ok or overall < self.cfg.min_overall_confidence:
                return None

            # Sincroniza saldo real da API antes de calcular posição
            self._sync_balance(symbol)

            if not self.risk.daily_drawdown_ok():
                logger.warning("🛑 Drawdown diário atingido — travado")
                return None

            resistances = ind.get("resistances", []) if ind else []
            supports    = ind.get("supports",    []) if ind else []
            atr_15m     = ind.get("atr", entry.atr) if ind else entry.atr
            atr_safe    = max(entry.atr, atr_15m)

            _, tp1, tp2, tp3, sl = self.risk.calc_levels(
                entry.price, atr_safe, effective_bias, resistances, supports
            )
            rr = abs(tp1 - entry.price) / abs(entry.price - sl) if abs(entry.price - sl) > 1e-10 else 0

            if rr < self.cfg.min_rr:
                return None

            liq = self.risk.liquidation_price(entry.price, effective_bias)
            if not self.risk.sl_safe_from_liq(sl, liq, effective_bias):
                logger.warning(f"⚠️ {symbol}: SL próximo da liquidação — ignorando")
                return None

            qty = self.risk.calc_qty(entry.price, sl, rr)
            if qty <= 0:
                return None

            summary = f"TREND: {trend.summary}  ||  ENTRY: {entry.summary}"
            logger.info(
                f"   📐 {symbol} | qty={qty} | liq={liq:.4f} | "
                f"R/R={rr:.2f} | TP1={tp1:.4f} TP2={tp2:.4f} TP3={tp3:.4f}"
            )

            sig = TradeSignal(
                symbol=symbol, direction=effective_bias,
                trend_score=trend.score, entry_score=entry.score,
                overall_confidence=overall * 100,
                confluence_pct=entry.confluence / entry.total_signals,
                price=entry.price, stop_loss=sl,
                take_profit=tp1,
                risk_reward=rr, atr=atr_safe,
                leverage=self.cfg.leverage,
                summary=summary, timestamp=datetime.now(),
            )
            # Armazena tp2 e tp3 no objeto para uso na gestão
            sig._tp2 = tp2
            sig._tp3 = tp3
            return sig

        except Exception as e:
            logger.error(f"❌ Erro ao analisar {symbol}: {e}")
            return None

    # ── Abertura de posição ───────────────────────────────────────────────────

    async def execute_trade(self, sig: TradeSignal) -> bool:
        # Se já tem posição nesse símbolo, tenta piramide
        if sig.symbol in self.open_positions:
            return await self.try_pyramid(sig)

        if len(self.open_positions) >= self.cfg.max_positions:
            return False

        # ── Proteção anti-churn: cooldown por ciclos ─────────────────────────
        last_cycle = self.last_close_cycle.get(sig.symbol, 0)
        if self.iteration - last_cycle < self.cfg.reentry_cooldown_cycles:
            remaining = self.cfg.reentry_cooldown_cycles - (self.iteration - last_cycle)
            logger.info(f"   ⏳ {sig.symbol} em cooldown — {remaining} ciclo(s) restantes")
            return False

        # ── Proteção anti-churn: cooldown por tempo real ─────────────────────
        last_close_t = self.last_close_time.get(sig.symbol)
        if last_close_t is not None:
            elapsed = (datetime.now() - last_close_t).total_seconds()
            if elapsed < self.cfg.reentry_cooldown_seconds:
                wait = int(self.cfg.reentry_cooldown_seconds - elapsed)
                logger.info(f"   ⏳ {sig.symbol} cooldown de tempo — aguarda {wait}s")
                return False

        # ── Proteção: perdas consecutivas ────────────────────────────────────
        consec = self.consecutive_losses.get(sig.symbol, 0)
        if consec >= self.cfg.max_consecutive_losses:
            logger.warning(f"   🛑 {sig.symbol} pausado — {consec} perdas seguidas")
            return False

        # ── Proteção: limite de perda diária por símbolo ─────────────────────
        daily_loss = self.daily_loss_pct.get(sig.symbol, 0.0)
        if daily_loss <= -self.cfg.max_daily_loss_pct:
            logger.warning(f"   🛑 {sig.symbol} parado hoje — perda diária {daily_loss*100:.1f}%")
            return False

        side     = "buy"  if sig.direction == Direction.LONG else "sell"
        pos_side = "long" if sig.direction == Direction.LONG else "short"

        logger.info(f"{'─'*65}")
        logger.info(
            f"🎯 NOVA POSIÇÃO {sig.symbol} {pos_side.upper()} | "
            f"conf {sig.overall_confidence:.1f}% | R/R {sig.risk_reward:.2f}"
        )
        logger.info(
            f"   Entrada: {sig.price:.6f}  SL: {sig.stop_loss:.6f}  "
            f"TP1: {sig.take_profit:.6f}  TP2: {getattr(sig,'_tp2',sig.take_profit):.6f}"
        )

        qty = self.risk.calc_qty(sig.price, sig.stop_loss, sig.risk_reward)
        if qty <= 0:
            return False

        # Bitget rejeita ordens abaixo de 5 USDT de valor nocional (erro 45110)
        notional = qty * sig.price
        if notional < 5.0:
            logger.warning(f"   ⚠️ {sig.symbol} ordem ignorada — nocional {notional:.2f} USDT < mínimo 5 USDT")
            return False

        if not self.testnet:
            # Força leverage correto na conta (Bitget ignora leverage na ordem)
            margin_coin = self.api.margin_coin(sig.symbol)
            lev_result = await self.api.set_leverage(sig.symbol, sig.leverage, margin_coin)
            if lev_result.get("code") != "00000":
                logger.warning(f"   ⚠️ set_leverage retornou: {lev_result}")

            result = await self.api.place_order(
                symbol=sig.symbol, side=side, position_side=pos_side,
                order_type="market", quantity=qty,
                leverage=sig.leverage,
                stop_loss=sig.stop_loss,
            )
            if result.get("code") != "00000":
                logger.error(f"   ❌ Falha na ordem: {result}")
                # Cooldown longo após falha — evita spam de ordens rejeitadas
                self.last_close_cycle[sig.symbol] = self.iteration
                self.last_close_time[sig.symbol]  = datetime.now()
                return False
            logger.info(f"   ✅ Ordem enviada: {result}")

            # Coloca SL no exchange imediatamente — protege mesmo se bot parar
            await asyncio.sleep(1)  # aguarda posição aparecer na exchange
            sl_result = await self.api.set_position_sl(sig.symbol, pos_side, sig.stop_loss)
            if sl_result.get("code") == "00000":
                logger.info(f"   🛡️ SL colocado no exchange: {sig.stop_loss:.4f}")
            else:
                logger.warning(f"   ⚠️ Falha ao colocar SL no exchange: {sl_result}")

        tp2 = getattr(sig, "_tp2", sig.take_profit)
        tp3 = getattr(sig, "_tp3", sig.take_profit)

        pos = OpenPosition(
            symbol=sig.symbol,
            direction=sig.direction,
            entries=[PositionEntry(sig.price, qty, datetime.now())],
            avg_entry=sig.price,
            total_qty=qty,
            initial_sl=sig.stop_loss,
            current_sl=sig.stop_loss,
            tp1=sig.take_profit,
            tp2=tp2,
            tp3=tp3,
            atr=sig.atr,
            confidence=sig.overall_confidence,
        )
        self.open_positions[sig.symbol] = pos
        self.last_trend[sig.symbol] = sig.direction

        self.sim.record(SimulatedTrade(
            symbol=sig.symbol, direction=pos_side,
            entry=sig.price, stop_loss=sig.stop_loss,
            take_profit=sig.take_profit, risk_reward=sig.risk_reward,
            confidence=sig.overall_confidence,
            confluence_pct=sig.confluence_pct,
            timestamp=sig.timestamp.isoformat(),
        ))
        return True

    # ── Pirâmide: adiciona à posição existente ────────────────────────────────

    async def try_pyramid(self, sig: TradeSignal) -> bool:
        pos = self.open_positions.get(sig.symbol)
        if pos is None:
            return False
        if pos.direction != sig.direction:
            return False
        if pos.pyramid_count >= self.cfg.max_pyramid_entries:
            return False
        if sig.overall_confidence < self.cfg.pyramid_min_confidence * 100:
            return False

        size_ratio = self.cfg.pyramid_size_ratio ** pos.pyramid_count
        qty = self.risk.calc_qty(sig.price, pos.current_sl, sig.risk_reward,
                                  size_ratio=size_ratio)
        if qty <= 0:
            return False

        side     = "buy"  if sig.direction == Direction.LONG else "sell"
        pos_side = "long" if sig.direction == Direction.LONG else "short"

        logger.info(f"   ➕ PIRÂMIDE #{pos.pyramid_count + 1} {sig.symbol} | qty={qty} | conf={sig.overall_confidence:.1f}%")

        if qty * sig.price < 5.0:
            logger.warning(f"   ⚠️ {sig.symbol} pirâmide ignorada — nocional {qty*sig.price:.2f} USDT < mínimo 5 USDT")
            return False

        if not self.testnet:
            result = await self.api.place_order(
                symbol=sig.symbol, side=side, position_side=pos_side,
                order_type="market", quantity=qty,
                leverage=sig.leverage,
                stop_loss=pos.current_sl,
            )
            if result.get("code") != "00000":
                logger.error(f"   ❌ Pirâmide falhou: {result}")
                return False

        # Atualiza média de entrada
        total_cost  = pos.avg_entry * pos.total_qty + sig.price * qty
        pos.total_qty   += qty
        pos.avg_entry    = total_cost / pos.total_qty
        pos.pyramid_count += 1
        pos.entries.append(PositionEntry(sig.price, qty, datetime.now()))
        pos.confidence = max(pos.confidence, sig.overall_confidence)

        logger.info(f"   ✅ Pirâmide ok | avg_entry={pos.avg_entry:.6f} | total_qty={pos.total_qty}")
        return True

    # ── Monitoramento ativo de posições ───────────────────────────────────────

    async def monitor_positions(self):
        """
        Gestão ativa: trailing stop, parciais, RSI exit, SL breakeven, reentrada.
        """
        closed_symbols = []

        for symbol, pos in list(self.open_positions.items()):
            try:
                ind = await self.analyzer.get_current_price_and_indicators(
                    self.api, symbol, "5m"
                )
                if ind is None:
                    continue

                price = ind["price"]
                rsi   = ind["rsi"]
                pos_side = "long" if pos.direction == Direction.LONG else "short"

                gain_atr = (
                    (price - pos.avg_entry) / pos.atr
                    if pos.direction == Direction.LONG
                    else (pos.avg_entry - price) / pos.atr
                )

                # ── 1. Verificar SL ──────────────────────────────────────────
                hit_sl = (
                    (pos.direction == Direction.LONG  and price <= pos.current_sl) or
                    (pos.direction == Direction.SHORT and price >= pos.current_sl)
                )
                if hit_sl:
                    await self._close_position(symbol, pos, price, "SL", pos_side)
                    closed_symbols.append(symbol)
                    continue

                # ── 2. Breakeven automático ─────────────────────────────────
                if not pos.breakeven_set and gain_atr >= self.cfg.breakeven_atr_mult:
                    new_sl = pos.avg_entry
                    better_sl = (
                        (pos.direction == Direction.LONG  and new_sl > pos.current_sl) or
                        (pos.direction == Direction.SHORT and new_sl < pos.current_sl)
                    )
                    if better_sl:
                        pos.current_sl   = new_sl
                        pos.breakeven_set = True
                        pos.phase         = PositionPhase.BREAKEVEN
                        logger.info(f"   🔒 {symbol} breakeven: SL={pos.current_sl:.6f} (+{gain_atr:.1f}ATR)")
                        if not self.testnet:
                            await self._safe_set_sl(symbol, pos_side, pos.current_sl, price)

                # ── 7. Trailing stop ─────────────────────────────────────────
                if gain_atr >= self.cfg.trailing_start_mult:
                    trail_sl = self.risk.calc_trailing_sl(price, pos.atr, pos.direction)
                    better_sl = (
                        (pos.direction == Direction.LONG  and trail_sl > pos.current_sl) or
                        (pos.direction == Direction.SHORT and trail_sl < pos.current_sl)
                    )
                    if better_sl:
                        old_sl = pos.current_sl
                        pos.current_sl = trail_sl
                        pos.phase      = PositionPhase.TRAILING
                        logger.info(
                            f"   🔄 {symbol} trailing SL: {old_sl:.6f} → {pos.current_sl:.6f} "
                            f"(preço={price:.6f} +{gain_atr:.1f}ATR)"
                        )
                        if not self.testnet:
                            await self._safe_set_sl(symbol, pos_side, pos.current_sl, price)

                # ── Log de status ─────────────────────────────────────────────
                phase_icon = {
                    PositionPhase.ENTRY:     "🟡",
                    PositionPhase.BREAKEVEN: "🔒",
                    PositionPhase.TRAILING:  "🔄",
                    PositionPhase.PARTIAL1:  "💰",
                    PositionPhase.PARTIAL2:  "💰💰",
                }.get(pos.phase, "?")
                logger.info(
                    f"   {phase_icon} {symbol} {pos_side.upper()} | "
                    f"preço={price:.4f} | ganho={gain_atr:+.2f}ATR | RSI={rsi:.1f} | "
                    f"SL={pos.current_sl:.4f} | pir={pos.pyramid_count}x"
                )

            except Exception as e:
                logger.error(f"❌ Erro monitorando {symbol}: {e}")

        for s in closed_symbols:
            self.open_positions.pop(s, None)
            self.last_close_cycle[s] = self.iteration
            self.last_close_time[s]  = datetime.now()

    async def _close_position(self, symbol: str, pos: OpenPosition,
                               price: float, reason: str, pos_side: str):
        logger.info(f"   {'✅' if reason != 'SL' else '❌'} {symbol} {pos_side.upper()} fechado ({reason}) @ {price:.6f}")
        if not self.testnet:
            # Fecha APENAS os contratos do bot — não afeta posições manuais do usuário
            await self._close_partial(symbol, pos_side, int(pos.total_qty))
        pnl_pct = (
            (price - pos.avg_entry) / pos.avg_entry * 100
            if pos.direction == Direction.LONG
            else (pos.avg_entry - price) / pos.avg_entry * 100
        ) * self.cfg.leverage
        won     = pnl_pct > 0
        pnl_dot = pnl_pct / 100 * self.risk.balance
        self.risk.record_result(won, pnl_dot)
        coin = self._coin_from_symbol(symbol)
        logger.info(
            f"   PnL: {pnl_pct:+.2f}%  ({pnl_dot:+.4f} {coin}) | "
            f"Saldo interno: {self.risk.balance:.4f} {coin}"
        )

        # ── Rastreia proteções por símbolo ───────────────────────────────────
        if won:
            self.consecutive_losses[symbol] = 0
            self.last_profitable[symbol] = {
                "entry":        pos.avg_entry,
                "exit":         price,
                "direction":    pos.direction,
                "reentry_used": False,
            }
        else:
            self.consecutive_losses[symbol] = self.consecutive_losses.get(symbol, 0) + 1
            consec = self.consecutive_losses[symbol]
            if consec >= self.cfg.max_consecutive_losses:
                logger.warning(
                    f"   🛑 {symbol}: {consec} perdas seguidas — pausado por 30 min"
                )

        raw_pnl_pct = pnl_pct / (self.cfg.leverage or 1) / 100
        self.daily_loss_pct[symbol] = self.daily_loss_pct.get(symbol, 0.0) + raw_pnl_pct

        # Registra simulação
        for t in self.sim.trades:
            if t.symbol == symbol and t.result == "open":
                t.result  = "win" if won else "loss"
                t.pnl_pct = pnl_pct
                break

    def _sync_balance(self, symbol: str) -> float:
        """
        Sincroniza self.risk.balance com o saldo real da Bitget para o símbolo.
        DOTUSD usa saldo de DOT, NEARUSD usa saldo de NEAR, etc.
        Retorna o saldo real, ou o saldo interno se não houver dado da API.
        """
        coin = self._coin_from_symbol(symbol)
        real = self.live_balances.get(coin, 0.0)
        if real > 0:
            if abs(real - self.risk.balance) > 0.001:
                logger.info(
                    f"   💼 Saldo {coin} real: {real:.4f} "
                    f"(interno era {self.risk.balance:.4f})"
                )
            self.risk.balance      = real
            self.risk.peak_balance = max(self.risk.peak_balance, real)
        return self.risk.balance

    async def _fib_reentry_signal(self, symbol: str) -> Optional[Direction]:
        """Verifica se o preço retornou a nível Fibonacci após trade lucrativo.
        Níveis: 38.2%, 50%, 61.8% da amplitude do trade anterior."""
        info = self.last_profitable.get(symbol)
        if not info or info["reentry_used"]:
            return None

        entry     = info["entry"]
        exit_p    = info["exit"]
        direction = info["direction"]
        rng       = abs(exit_p - entry)

        if rng < entry * 0.001:  # movimento insignificante
            return None

        if direction == Direction.LONG:
            fibs = [exit_p - rng * lvl for lvl in (0.382, 0.500, 0.618)]
        else:
            fibs = [exit_p + rng * lvl for lvl in (0.382, 0.500, 0.618)]

        ind = await self.analyzer.get_current_price_and_indicators(self.api, symbol, "5m")
        if not ind:
            return None
        price = ind["price"]
        rsi   = ind["rsi"]

        tolerance = price * 0.004  # ±0.4%
        nearest_fib = None
        for fib, lvl in zip(fibs, (38.2, 50.0, 61.8)):
            if abs(price - fib) <= tolerance:
                nearest_fib = lvl
                break

        if nearest_fib is None:
            return None

        # RSI ainda favorável — preço não reverteu completamente
        if direction == Direction.LONG and rsi > 58:
            return None
        if direction == Direction.SHORT and rsi < 42:
            return None

        logger.info(
            f"   📐 {symbol}: Fib {nearest_fib:.1f}% atingido "
            f"(entrada={entry:.4f} saída={exit_p:.4f} preço={price:.4f}) "
            f"→ re-entrada {direction.value.upper()}"
        )
        return direction

    async def _sync_positions_from_api(self):
        """
        Sincroniza posições abertas da API para self.open_positions.
        Captura posições abertas manualmente e remove as já fechadas.
        """
        try:
            api_positions = await self.api.get_open_positions()
            if not isinstance(api_positions, list):
                logger.info(f"   🔍 Sync posições: resposta inesperada ({type(api_positions).__name__}): {api_positions}")
                return

            logger.info(f"   🔍 Sync posições: {len(api_positions)} posição(ões) na API")

            # Mapa: symbol → dados da API
            api_map: Dict[str, dict] = {}
            for p in api_positions:
                sym   = p.get("symbol", "")
                total = float(p.get("total", 0) or 0)
                logger.info(f"      → {sym} holdSide={p.get('holdSide')} total={total} available={p.get('available')}")
                if total > 0:
                    api_map[sym] = p

            # Remove posições fechadas externamente
            for sym in list(self.open_positions.keys()):
                if sym not in api_map:
                    logger.info(f"   🔄 {sym}: posição fechada externamente — removendo do rastreio")
                    self.open_positions.pop(sym, None)

            # Importa posições abertas manualmente (não rastreadas)
            for sym, p in api_map.items():
                if sym in self.open_positions:
                    continue  # já rastreada
                if sym not in [s for s in self.symbols]:
                    continue  # fora da lista de símbolos monitorados

                hold_side  = p.get("holdSide", "long")
                direction  = Direction.LONG if hold_side == "long" else Direction.SHORT
                avg_entry  = float(p.get("openPriceAvg", 0))
                total_qty  = float(p.get("total", 1))

                # Busca ATR atual para calcular SL/TP conservadores
                ind = await self.analyzer.get_current_price_and_indicators(self.api, sym, "1H")
                atr = float(ind.get("atr", avg_entry * 0.01)) if ind else avg_entry * 0.01

                if direction == Direction.LONG:
                    sl   = avg_entry - atr * 1.5
                    tp1  = avg_entry + atr * 1.0
                    tp2  = avg_entry + atr * 1.5
                    tp3  = avg_entry + atr * 2.0
                else:
                    sl   = avg_entry + atr * 1.5
                    tp1  = avg_entry - atr * 1.0
                    tp2  = avg_entry - atr * 1.5
                    tp3  = avg_entry - atr * 2.0

                pos = OpenPosition(
                    symbol=sym,
                    direction=direction,
                    entries=[PositionEntry(avg_entry, total_qty, datetime.now())],
                    avg_entry=avg_entry,
                    total_qty=total_qty,
                    initial_sl=sl,
                    current_sl=sl,
                    tp1=tp1,
                    tp2=tp2,
                    tp3=tp3,
                    atr=atr,
                    confidence=0.70,
                )
                self.open_positions[sym] = pos
                self.last_trend[sym] = direction
                logger.info(
                    f"   📥 {sym}: posição {hold_side.upper()} importada da API "
                    f"(qty={total_qty}, entry={avg_entry:.4f}, SL={sl:.4f})"
                )

        except Exception as e:
            logger.warning(f"⚠️ Erro ao sincronizar posições da API: {e}")

    async def _check_rsi_cascade(self, symbol: str,
                                  direction: Direction) -> Tuple[int, int, str]:
        """
        RSI cascata Elder Triple Screen.
        Retorna (score_ponderado, n_tfs_no_extremo, resumo).
        Scoring: 1D=3pts, 4H=2pts, 1H=1pt
        Threshold: ≤rsi_cascade_threshold para LONG, ≥(100-threshold) para SHORT.
        """
        os_thresh = self.cfg.rsi_cascade_threshold
        ob_thresh = 100.0 - os_thresh
        tfs = [("1D", 3), ("4H", 2), ("1H", 1)]
        score    = 0
        tf_count = 0
        parts    = []
        for tf, weight in tfs:
            ind = await self.analyzer.get_current_price_and_indicators(self.api, symbol, tf)
            rsi = ind["rsi"] if ind else 50.0
            hit = (
                (direction == Direction.LONG  and rsi <= os_thresh) or
                (direction == Direction.SHORT and rsi >= ob_thresh)
            )
            if hit:
                score    += weight
                tf_count += 1
                parts.append(f"{tf}:{rsi:.0f}✓")
            else:
                parts.append(f"{tf}:{rsi:.0f}")
        return score, tf_count, " | ".join(parts)

    async def _safe_set_sl(self, symbol: str, pos_side: str, sl_price: float,
                           current_price: float) -> bool:
        """Valida SL antes de enviar e trata erro 40836 fechando posição."""
        # Validação: SL de SHORT deve estar ACIMA do preço atual
        if pos_side == "short" and sl_price <= current_price:
            logger.warning(f"   ⚠️ {symbol} SHORT SL inválido ({sl_price:.6f} <= preço {current_price:.6f}) — ignorando atualização")
            return False
        # Validação: SL de LONG deve estar ABAIXO do preço atual
        if pos_side == "long" and sl_price >= current_price:
            logger.warning(f"   ⚠️ {symbol} LONG SL inválido ({sl_price:.6f} >= preço {current_price:.6f}) — ignorando atualização")
            return False

        result = await self.api.set_position_sl(symbol, pos_side, sl_price)
        if result.get("code") == "40836":
            logger.error(f"   ❌ {symbol} erro 40836 SL inválido — fechando posição a mercado")
            await self.api.close_position(symbol, pos_side)
            return False
        if result.get("code") != "00000":
            logger.error(f"   ❌ {symbol} set_sl falhou: {result}")
            return False
        return True

    async def _close_partial(self, symbol: str, pos_side: str, qty: float):
        side = "sell" if pos_side == "long" else "buy"
        data = {
            "symbol":      symbol,
            "side":        side,
            "tradeSide":   "close",
            "orderType":   "market",
            "size":        str(int(qty)),
            "productType": self.api.product_type,
            "marginCoin":  self.api.margin_coin(symbol),
        }
        result = await self.api._request("POST", "/mix/order/place-order", data=data)
        if result.get("code") != "00000":
            logger.error(f"   ❌ Parcial falhou: {result}")

    # ── Loop principal ────────────────────────────────────────────────────────

    async def run(self):
        logger.info(f"\n{'='*65}")
        logger.info(f"🚀 AGENTE v4 INICIADO | {'TESTNET/SIM' if self.testnet else 'LIVE ⚠️'}")
        logger.info(f"   Monitorando {len(self.symbols)} moeda(s) possíveis")
        logger.info(f"{'='*65}\n")

        active_symbols = list(self.symbols)  # começa com todas, filtra pelo saldo

        async with self.api:
            try:
                # ── Lê saldo real da API antes do primeiro ciclo ──────────────
                try:
                    initial_balances = await self.api.get_account_balances()
                    if initial_balances:
                        self.live_balances = initial_balances
                        # Inicializa RiskManager com saldo real da primeira moeda ativa
                        for sym in self.symbols:
                            coin = self._coin_from_symbol(sym)
                            if coin in initial_balances:
                                self.risk.balance      = initial_balances[coin]
                                self.risk.peak_balance = initial_balances[coin]
                                self.risk.daily_start  = initial_balances[coin]
                                logger.info(f"   💼 Saldo inicial {coin}: {initial_balances[coin]:.4f}")
                                break
                except Exception as e:
                    logger.warning(f"⚠️ Não foi possível ler saldo inicial: {e}")

                # ── Importa posições já abertas (manual ou sessão anterior) ───
                await self._sync_positions_from_api()

                while True:
                    self.iteration += 1
                    ts = datetime.now().strftime("%H:%M:%S")
                    n_pos = len(self.open_positions)

                    # A cada 10 ciclos verifica quais moedas têm saldo e sincroniza posições
                    if self.iteration == 1 or self.iteration % 10 == 0:
                        try:
                            balances = await self.api.get_account_balances()
                            if balances:
                                self.live_balances = balances  # atualiza saldos reais
                                # Filtra símbolos cuja moeda base tem saldo
                                active_symbols = [
                                    s for s in self.symbols
                                    if self._coin_from_symbol(s) in balances
                                ]
                                coins_with_balance = {
                                    self._coin_from_symbol(s): balances.get(self._coin_from_symbol(s), 0)
                                    for s in active_symbols
                                }
                                logger.info(f"   💼 Saldos detectados: {coins_with_balance}")
                                logger.info(f"   ✅ Moedas ativas: {active_symbols}")
                                sem_saldo = [s for s in self.symbols if s not in active_symbols]
                                if sem_saldo:
                                    logger.info(f"   ⏸  Sem saldo (inativas): {sem_saldo}")
                            else:
                                active_symbols = list(self.symbols)
                        except Exception as e:
                            logger.warning(f"⚠️ Não foi possível verificar saldos: {e}")

                        # Sincroniza posições abertas externamente (manual ou outra sessão)
                        await self._sync_positions_from_api()

                    logger.info(f"[{ts}] Ciclo #{self.iteration} | ativos: {len(active_symbols)} | posições: {n_pos}")

                    if not active_symbols:
                        logger.warning("⚠️ Nenhuma moeda com saldo disponível. Aguardando...")
                        await asyncio.sleep(self.interval)
                        continue

                    market_bias, btc_lateral = await self.get_market_bias()

                    # Monitoramento ativo PRIMEIRO
                    if self.open_positions:
                        await self.monitor_positions()

                    # Busca novos sinais apenas nas moedas com saldo
                    signals = await asyncio.gather(
                        *[self.analyze_symbol(s, market_bias, btc_lateral) for s in active_symbols],
                        return_exceptions=True,
                    )
                    for sig in signals:
                        if isinstance(sig, Exception) or sig is None:
                            continue
                        await self.execute_trade(sig)

                    if self.iteration % 20 == 0:
                        self.sim.print_report()
                        self.risk.print_risk_report()
                        self.risk.reset_daily()
                        # Reseta contadores diários por símbolo (a cada ~10 min)
                        self.daily_loss_pct.clear()
                        self.consecutive_losses.clear()

                    await asyncio.sleep(self.interval)

            except KeyboardInterrupt:
                logger.info("\n⛔ Interrompido pelo usuário")
                self.sim.print_report()

    @staticmethod
    def _coin_from_symbol(symbol: str) -> str:
        """DOTUSD → DOT, ETHUSD → ETH, BTCUSD → BTC"""
        for suffix in ("USD", "USDT", "PERP"):
            if symbol.endswith(suffix):
                return symbol[: -len(suffix)].upper()
        return symbol.upper()


# ============================================================================
# CONFIGURAÇÃO E EXECUÇÃO
# ============================================================================

async def main():
    API_KEY    = os.getenv("BITGET_API_KEY",    "")
    API_SECRET = os.getenv("BITGET_API_SECRET", "")
    PASSPHRASE = os.getenv("BITGET_PASSPHRASE", "")

    if not API_KEY or API_KEY in ("seu_api_key", ""):
        logger.error("❌ BITGET_API_KEY não configurada. Crie o arquivo .env na pasta do bot.")
        logger.error("   Veja o arquivo .env.example para o formato correto.")
        sys.exit(1)

    # ── Todas as moedas COIN-M Perpetual disponíveis na Bitget ───────────────
    # O bot verifica automaticamente quais têm saldo antes de operar.
    # Você só precisará ter saldo na moeda para o bot ativá-la.
    SYMBOLS = [
        "BTCUSD",
        "ETHUSD",
        "DOTUSD",
        "SOLUSD",
        "XRPUSD",
        "ADAUSD",
        "LINKUSD",
        "LTCUSD",
        "AVAXUSD",
        "BNBUSD",
        "MATICUSD",
        "ATOMUSD",
        "NEARUSD",
        "FILUSD",
        "TRXUSD",
    ]

    config = StrategyConfig(
        name="RSI_CASCADE_v5",
        leverage=5,                       # 5x
        risk_percent=0.01,                # 1% por trade
        max_positions=2,                  # 1 por símbolo (DOT + NEAR simultâneos)
        min_trend_confluence=0.55,
        min_entry_confluence=0.55,
        min_overall_confidence=0.52,
        tp_atr_mult=1.0,                  # TP mais rápido — fecha em 1x ATR
        sl_atr_mult=0.8,                  # SL apertado para R/R viável
        min_rr=1.2,                       # R/R mínimo reduzido para mais entradas
        max_pyramid_entries=0,            # sem pirâmide — trades rápidos
        pyramid_min_confidence=0.80,
        pyramid_size_ratio=0.5,
        breakeven_atr_mult=0.5,
        trailing_start_mult=0.8,
        trailing_distance_mult=0.5,
        partial_tp1_pct=0.60,             # fecha 60% no TP1
        partial_tp2_pct=0.40,             # fecha restante no TP2
        rsi_cascade_threshold=30.0,       # RSI ≤30 LONG / ≥70 SHORT
        rsi_cascade_min_tfs=1,            # 1 TF basta
        rsi_long_exit=62.0,               # sai do long quando RSI ≥ 62 (saída rápida)
        rsi_short_exit=38.0,              # sai do short quando RSI ≤ 38 (saída rápida)
        reentry_cooldown_cycles=20,       # 20 × 30s = 10 min entre trades
        reentry_cooldown_seconds=600,
        max_consecutive_losses=3,
        max_daily_loss_pct=0.06,
    )

    agent = BitgetTradingAgent(
        api_key=API_KEY, api_secret=API_SECRET, passphrase=PASSPHRASE,
        account_balance=1.0,   # placeholder — substituído pelo saldo real da API ao iniciar
        symbols=SYMBOLS,
        config=config,
        product_type="COIN-FUTURES",
        check_interval=30,
        testnet=False,
    )

    await agent.run()


if __name__ == "__main__":
    asyncio.run(main())
