#!/usr/bin/env bash
# Inicia bot e painel
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  echo "❌ Ambiente não instalado. Rode primeiro: ./instalar.sh"
  exit 1
fi

# Reinicia se já estiver rodando, senão inicia do zero
pm2 delete bitget-bot bitget-painel 2>/dev/null || true

echo "🚀 Iniciando bot..."
pm2 start bitget_perpetual_agent.py \
  --interpreter ./.venv/bin/python3 \
  --name bitget-bot \
  --output trading_agent.log \
  --error trading_agent.log

echo "🖥️  Iniciando painel..."
pm2 start ./.venv/bin/streamlit \
  --name bitget-painel \
  --interpreter none \
  -- run painel/Home.py \
     --server.port 8501 \
     --server.headless true \
     --browser.gatherUsageStats false

sleep 3
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  ✅ Tudo rodando!"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Painel: http://localhost:8501"
echo ""
echo "Status:    pm2 status"
echo "Log bot:   pm2 logs bitget-bot"
echo "Parar:     ./parar.sh"
echo ""

# Abre o painel no navegador (Mac/Linux)
if command -v open &> /dev/null; then
  open http://localhost:8501
elif command -v xdg-open &> /dev/null; then
  xdg-open http://localhost:8501
fi
