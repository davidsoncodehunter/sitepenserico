#!/usr/bin/env bash
# Instalador automático do Bot Bitget — rode apenas uma vez
set -e

cd "$(dirname "$0")"
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  Bot Bitget — Instalação automática"
echo "════════════════════════════════════════════════════════════"
echo ""

# ── 1. Python ───────────────────────────────────────────────────
if ! command -v python3 &> /dev/null; then
  echo "❌ Python 3 não encontrado."
  echo "   Instale em: https://www.python.org/downloads/"
  exit 1
fi
echo "✅ Python: $(python3 --version)"

# ── 2. Node + pm2 ──────────────────────────────────────────────
if ! command -v node &> /dev/null; then
  echo "❌ Node.js não encontrado."
  echo "   Instale em: https://nodejs.org (escolha a versão LTS)"
  exit 1
fi
echo "✅ Node: $(node --version)"

if ! command -v pm2 &> /dev/null; then
  echo "📦 Instalando pm2..."
  npm install -g pm2
fi
echo "✅ pm2: $(pm2 --version)"

# ── 3. Ambiente Python ─────────────────────────────────────────
if [ ! -d ".venv" ]; then
  echo "📦 Criando ambiente Python isolado..."
  python3 -m venv .venv
fi

echo "📦 Instalando bibliotecas (pode levar 2-3 min)..."
.venv/bin/pip install --upgrade pip --quiet
.venv/bin/pip install aiohttp pandas numpy anthropic python-dotenv ta cryptography \
  scikit-learn streamlit requests --quiet

# ── 4. .env ────────────────────────────────────────────────────
if [ ! -f ".env" ]; then
  cp .env.example .env
  chmod 600 .env
  echo "📝 Arquivo .env criado em branco (modo 600 — só você lê)"
fi

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  ✅ Instalação concluída!"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Próximos passos:"
echo "  1. Rode ./iniciar.sh para abrir o painel"
echo "  2. No painel, aba '🔑 Configurar Bitget', cole suas chaves"
echo "  3. O bot vai começar a operar"
echo ""
