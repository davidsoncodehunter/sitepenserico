"""
Painel ao vivo do Bot Bitget V1.2
Mostra: saldos COIN-M, posições abertas, log do bot em tempo real.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from datetime import datetime
from pathlib import Path

import requests
import streamlit as st
from dotenv import load_dotenv
import os

HERE = Path(__file__).resolve().parent
BOT_DIR = HERE.parent
LOG_PATH = BOT_DIR / "trading_agent.log"
ENV_PATH = BOT_DIR / ".env"

load_dotenv(ENV_PATH)

st.set_page_config(
    page_title="Bot Bitget V1.2 — Ao Vivo",
    page_icon="🤖",
    layout="wide",
)


# ─────────────────────────────────────────────────────────────────
# Cliente HTTP mínimo da Bitget COIN-M
# ─────────────────────────────────────────────────────────────────
class BitgetClient:
    BASE_URL = "https://api.bitget.com"
    PRODUCT  = "COIN-FUTURES"

    def __init__(self, key: str, secret: str, passphrase: str):
        self.key = key
        self.secret = secret
        self.passphrase = passphrase

    def _sign(self, ts: str, method: str, path: str, body: str = "") -> str:
        mac = hmac.new(self.secret.encode(),
                       (ts + method + path + body).encode(),
                       hashlib.sha256)
        return base64.b64encode(mac.digest()).decode()

    def _get(self, endpoint: str, params: dict | None = None) -> dict:
        ts = str(int(time.time() * 1000))
        path = f"/api/v2{endpoint}"
        if params:
            query = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
            sign_path = f"{path}?{query}"
        else:
            sign_path = path
        headers = {
            "Content-Type": "application/json",
            "ACCESS-KEY": self.key,
            "ACCESS-SIGN": self._sign(ts, "GET", sign_path),
            "ACCESS-TIMESTAMP": ts,
            "ACCESS-PASSPHRASE": self.passphrase,
        }
        try:
            r = requests.get(self.BASE_URL + path, headers=headers,
                             params=params, timeout=10)
            return r.json()
        except Exception as e:
            return {"code": "error", "msg": str(e)}

    def get_accounts(self) -> list:
        r = self._get("/mix/account/accounts", {"productType": self.PRODUCT})
        return r.get("data") or []

    def get_positions(self) -> list:
        r = self._get("/mix/position/all-position", {"productType": self.PRODUCT})
        return r.get("data") or []

    def get_ticker(self, symbol: str) -> dict:
        r = self._get("/mix/market/ticker",
                      {"symbol": symbol, "productType": self.PRODUCT})
        data = r.get("data") or []
        return data[0] if data else {}


# ─────────────────────────────────────────────────────────────────
# Estado da sessão (toggles)
# ─────────────────────────────────────────────────────────────────
if "hide_balance" not in st.session_state:
    st.session_state.hide_balance = False
if "hide_pnl" not in st.session_state:
    st.session_state.hide_pnl = False


def mask(value: str | float, hide: bool, length: int = 6) -> str:
    if hide:
        return "•" * length
    return str(value)


# ─────────────────────────────────────────────────────────────────
# Validação de credenciais
# ─────────────────────────────────────────────────────────────────
API_KEY    = os.getenv("BITGET_API_KEY", "")
API_SECRET = os.getenv("BITGET_API_SECRET", "")
PASSPHRASE = os.getenv("BITGET_PASSPHRASE", "")

if not (API_KEY and API_SECRET and PASSPHRASE):
    st.warning("⚠️ Credenciais Bitget ainda não configuradas.")
    st.markdown(
        "👉 Vá em **🔑 Configurar Bitget** no menu à esquerda para "
        "preencher suas chaves antes de continuar."
    )
    st.stop()

client = BitgetClient(API_KEY, API_SECRET, PASSPHRASE)


# ─────────────────────────────────────────────────────────────────
# Cabeçalho
# ─────────────────────────────────────────────────────────────────
col_title, col_refresh = st.columns([4, 1])
with col_title:
    st.title("🤖 Bot Bitget V1.2 — Ao Vivo")
    st.caption(f"COIN-M Perpetual · atualizado {datetime.now().strftime('%H:%M:%S')}")
with col_refresh:
    if st.button("🔄 Atualizar agora", use_container_width=True):
        st.rerun()
    auto = st.toggle("Auto-refresh 10s", value=False)


# ─────────────────────────────────────────────────────────────────
# Linha 1 — Saldos + Posições
# ─────────────────────────────────────────────────────────────────
col_bal, col_pos = st.columns([1, 2])

with col_bal:
    head1, head2 = st.columns([3, 1])
    with head1:
        st.subheader("💼 Saldos")
    with head2:
        if st.button("👁" if not st.session_state.hide_balance else "🙈",
                     key="toggle_bal", help="Ocultar saldo"):
            st.session_state.hide_balance = not st.session_state.hide_balance
            st.rerun()

    accounts = client.get_accounts()
    if not accounts:
        st.info("Sem saldos COIN-M ou erro na API.")
    else:
        rows = []
        for acc in accounts:
            coin = acc.get("marginCoin", "?")
            avail = float(acc.get("available", 0) or 0)
            locked = float(acc.get("locked", 0) or 0)
            if avail + locked <= 0:
                continue
            rows.append({
                "Moeda": coin,
                "Disponível": mask(f"{avail:.6f}", st.session_state.hide_balance),
                "Bloqueado": mask(f"{locked:.6f}", st.session_state.hide_balance),
            })
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)
        else:
            st.info("Nenhum saldo COIN-M encontrado.")

with col_pos:
    head1, head2 = st.columns([3, 1])
    with head1:
        st.subheader("📊 Posições abertas")
    with head2:
        if st.button("👁" if not st.session_state.hide_pnl else "🙈",
                     key="toggle_pnl", help="Ocultar PnL"):
            st.session_state.hide_pnl = not st.session_state.hide_pnl
            st.rerun()

    positions = client.get_positions()
    open_pos = [p for p in positions if float(p.get("total", 0) or 0) > 0]

    if not open_pos:
        st.info("Nenhuma posição aberta no momento.")
    else:
        rows = []
        for p in open_pos:
            sym = p.get("symbol", "?")
            direction = "LONG" if p.get("holdSide") == "long" else "SHORT"
            entry = float(p.get("openPriceAvg", 0) or 0)
            mark  = float(p.get("markPrice", 0) or 0)
            qty   = float(p.get("total", 0) or 0)
            upl   = float(p.get("unrealizedPL", 0) or 0)
            lev   = p.get("leverage", "?")

            if entry > 0:
                pnl_pct = (mark - entry) / entry * 100
                if direction == "SHORT":
                    pnl_pct = -pnl_pct
            else:
                pnl_pct = 0

            rows.append({
                "Símbolo": sym,
                "Direção": direction,
                "Qty": qty,
                "Lev": f"{lev}x",
                "Entrada": f"{entry:.4f}",
                "Atual": f"{mark:.4f}",
                "PnL %": mask(f"{pnl_pct:+.2f}%", st.session_state.hide_pnl),
                "PnL $": mask(f"{upl:+.4f}", st.session_state.hide_pnl),
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)


# ─────────────────────────────────────────────────────────────────
# Linha 2 — Log ao vivo
# ─────────────────────────────────────────────────────────────────
st.subheader("🪵 Log do bot")

col_filt, col_n = st.columns([2, 1])
with col_filt:
    filt = st.text_input("Filtrar (símbolo, palavra, vazio = tudo)", value="")
with col_n:
    n_lines = st.number_input("Últimas N linhas", 10, 500, 80, step=10)


def tail_log(path: Path, n: int, needle: str = "") -> list[str]:
    if not path.exists():
        return [f"[log ainda não existe: {path}]"]
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception as e:
        return [f"[erro lendo log: {e}]"]
    if needle:
        needle_l = needle.lower()
        lines = [ln for ln in lines if needle_l in ln.lower()]
    return lines[-n:]


log_lines = tail_log(LOG_PATH, int(n_lines), filt.strip())
st.code("".join(log_lines) if log_lines else "(sem linhas)",
        language="log", line_numbers=False)


# ─────────────────────────────────────────────────────────────────
# Auto-refresh
# ─────────────────────────────────────────────────────────────────
if auto:
    time.sleep(10)
    st.rerun()
