"""
Aba de configuração: a pessoa preenche as próprias chaves Bitget,
o painel testa a conexão e grava no .env local.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import time
from pathlib import Path

import requests
import streamlit as st

BOT_DIR = Path(__file__).resolve().parents[2]
ENV_PATH = BOT_DIR / ".env"

st.set_page_config(page_title="Configurar Bitget", page_icon="🔑", layout="centered")
st.title("🔑 Configurar acesso à Bitget")

st.info(
    "Suas chaves ficam **só no seu computador**, num arquivo `.env` protegido. "
    "Elas nunca são enviadas para nenhum servidor além da Bitget."
)


# ──────────────────────────────────────────────────────────────
# Ler valores atuais (se já houver)
# ──────────────────────────────────────────────────────────────
def parse_env(path: Path) -> dict:
    if not path.exists():
        return {}
    data = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        data[k.strip()] = v.strip()
    return data


def write_env(path: Path, data: dict) -> None:
    lines = [
        "# Arquivo gerado pelo painel — NUNCA compartilhe este arquivo.",
        f"BITGET_API_KEY={data.get('BITGET_API_KEY', '')}",
        f"BITGET_API_SECRET={data.get('BITGET_API_SECRET', '')}",
        f"BITGET_PASSPHRASE={data.get('BITGET_PASSPHRASE', '')}",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass


current = parse_env(ENV_PATH)


# ──────────────────────────────────────────────────────────────
# Instruções
# ──────────────────────────────────────────────────────────────
with st.expander("👉 Como gerar suas chaves na Bitget (passo a passo)", expanded=not current):
    st.markdown(
        """
1. Acesse **[bitget.com](https://www.bitget.com)** e faça login
2. Clique no seu avatar → **Gerenciamento de API**
3. Clique em **Criar API Key**
4. Em permissões marque:
   - ✅ **Read** (leitura)
   - ✅ **Futures Trading** (negociação de futuros)
   - ❌ **Withdraw** — **NUNCA** marque essa opção
5. Defina uma **Passphrase** e anote com cuidado
6. (Opcional, recomendado) Adicione seu IP em **IP Whitelist**
7. Copie os 3 valores: **API Key · Secret Key · Passphrase**
8. Cole abaixo e clique em **Testar e salvar**
"""
    )


# ──────────────────────────────────────────────────────────────
# Formulário
# ──────────────────────────────────────────────────────────────
with st.form("config_bitget"):
    api_key = st.text_input(
        "API Key", value=current.get("BITGET_API_KEY", ""),
        placeholder="bg_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    )
    api_secret = st.text_input(
        "API Secret", value=current.get("BITGET_API_SECRET", ""),
        type="password",
        placeholder="(sua secret key — mantenha em segredo)",
    )
    passphrase = st.text_input(
        "Passphrase", value=current.get("BITGET_PASSPHRASE", ""),
        type="password",
        placeholder="(a passphrase que você definiu na Bitget)",
    )

    col1, col2 = st.columns(2)
    submit = col1.form_submit_button("✅ Testar e salvar", use_container_width=True)
    clear  = col2.form_submit_button("🗑️ Limpar campos", use_container_width=True)


# ──────────────────────────────────────────────────────────────
# Teste de conexão
# ──────────────────────────────────────────────────────────────
def test_connection(key: str, secret: str, passp: str) -> tuple[bool, str]:
    if not (key and secret and passp):
        return False, "Preencha os 3 campos antes de testar."
    ts = str(int(time.time() * 1000))
    path = "/api/v2/mix/account/accounts"
    query = "productType=COIN-FUTURES"
    sign_path = f"{path}?{query}"
    mac = hmac.new(secret.encode(),
                   (ts + "GET" + sign_path).encode(),
                   hashlib.sha256)
    sign = base64.b64encode(mac.digest()).decode()
    headers = {
        "Content-Type": "application/json",
        "ACCESS-KEY": key,
        "ACCESS-SIGN": sign,
        "ACCESS-TIMESTAMP": ts,
        "ACCESS-PASSPHRASE": passp,
    }
    try:
        r = requests.get(
            "https://api.bitget.com" + path,
            headers=headers,
            params={"productType": "COIN-FUTURES"},
            timeout=10,
        )
        data = r.json()
        if data.get("code") == "00000":
            n = len(data.get("data") or [])
            return True, f"✅ Conectado! {n} moeda(s) COIN-M na conta."
        return False, f"❌ Bitget respondeu: {data.get('msg', 'erro desconhecido')} (code {data.get('code')})"
    except Exception as e:
        return False, f"❌ Falha de rede: {e}"


if clear:
    if ENV_PATH.exists():
        ENV_PATH.unlink()
    st.success("Campos e arquivo .env limpos.")
    st.rerun()

if submit:
    ok, msg = test_connection(api_key, api_secret, passphrase)
    if ok:
        write_env(ENV_PATH, {
            "BITGET_API_KEY": api_key,
            "BITGET_API_SECRET": api_secret,
            "BITGET_PASSPHRASE": passphrase,
        })
        st.success(msg)
        st.success(f"💾 Salvo em `{ENV_PATH}` (modo 600 — só seu usuário lê).")
        st.info("Agora reinicie o bot para usar as novas chaves: `pm2 restart bitget-bot`")
    else:
        st.error(msg)
        st.warning("⚠️ Nada foi salvo. Confira API Key, Secret e Passphrase na Bitget.")


# ──────────────────────────────────────────────────────────────
# Avisos de segurança
# ──────────────────────────────────────────────────────────────
st.divider()
st.subheader("🛡️ Segurança — leia antes de usar")
st.markdown(
    """
- ✅ Suas chaves ficam **só no seu computador** (no arquivo `.env` local)
- ✅ O `.gitignore` deste projeto bloqueia o `.env` de ser versionado
- ❌ **NUNCA** suba o `.env` para Google Drive, GitHub, Dropbox ou qualquer nuvem pública
- ❌ **NUNCA** mostre o conteúdo do `.env` em screenshot, vídeo ou print
- ❌ **NUNCA** compartilhe suas chaves com terceiros (suporte, "ajudantes", etc.)
- ❌ **NUNCA** marque a permissão **Withdraw** na API Key

Se desconfiar que vazaram: vá em **bitget.com → API Management** e revogue
imediatamente. Depois gere chaves novas e atualize aqui.
"""
)
