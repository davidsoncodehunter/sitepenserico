#!/usr/bin/env bash
# Para bot e painel (não fecha posições abertas)
cd "$(dirname "$0")"
pm2 stop bitget-bot bitget-painel 2>/dev/null || true
echo "⏸️  Bot e painel parados."
echo "   (Posições abertas na Bitget continuam — feche manualmente se quiser)"
