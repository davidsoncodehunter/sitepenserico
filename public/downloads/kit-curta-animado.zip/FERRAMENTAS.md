# Kit Curta Animado com o Claude: todas as ferramentas

V = citada ou mostrada na aula · L = está na lista extra para explorar
Links conferidos em 24/11/2026. Leia a licença antes de usar comercialmente e baixe só da página oficial.

## A base (instale primeiro)
- **Claude** (V): dirige tudo: escreve, programa, anima e confere. https://claude.com/download
- **FFmpeg** (V): corta, junta, trata cor e mistura o som. https://github.com/FFmpeg/FFmpeg · LGPL/GPL
- **Whisper (whisper.cpp)** (V): acha o tempo certo de cada palavra. https://github.com/ggml-org/whisper.cpp · MIT
- **WhisperX** (V): legenda palavra por palavra, alinhada. https://github.com/m-bain/whisperX · BSD-2
- **yt-dlp** (V): baixa a legenda para estudar uma referência. https://github.com/yt-dlp/yt-dlp · Unlicense
- **Blender** (V): o 3D. https://www.blender.org/download/ · GPL
- **Vision (Apple)** (V): separa a pessoa do fundo; já vem no Mac. https://developer.apple.com/documentation/vision
- **Google Fonts** (V): as letras do vídeo. https://fonts.google.com · livres
- **Pixabay** (V): música e efeitos gratuitos. https://pixabay.com/music/ · licença Pixabay
- **ChatGPT** (V): pode desenhar o personagem em peças para recortar. https://chatgpt.com

## Desenho e movimento
- **Remotion** (V): o código vira quadro do vídeo. https://github.com/remotion-dev/remotion · grátis para pessoa e empresa pequena; veja a licença
- **Remotion Skills** (V): skill oficial de boas práticas. https://github.com/remotion-dev/skills · sem licença declarada
- **React** (V): as bibliotecas de animação rodam nele. https://react.dev · MIT
- **reanimate** (V): entende uma animação quadro a quadro e refaz. https://github.com/NiazMorshed2007/reanimate · MIT
- **motion-design-skill** (V): tempo e curva de animador. https://github.com/LottieFiles/motion-design-skill · MIT
- **mg-styles-15** (V): 15 estilos de motion, um prompt cada. https://github.com/Vincentwei1021/mg-styles-15 · MIT
- **huashu-art-motion** (V): pinturas que se mexem, 35 estilos. https://github.com/alchaincyf/huashu-art-motion · MIT
- **cinetic** (V): filme de lançamento em código. https://github.com/Leonxlnx/cinetic · MIT
- **react-postprocessing** (V): luz, brilho e acabamento de cinema. https://github.com/pmndrs/react-postprocessing · MIT
- **viral-claude-shorts** (V): narração vira vídeo vertical animado. https://github.com/hans1801/viral-claude-shorts · sem licença declarada: use para estudar
- **anidoodle** (L): rabiscos e loops em código. https://github.com/alexgreensh/anidoodle · Apache-2.0
- **motionmaxxing** (L): tira a cara de vídeo de IA. https://github.com/Tejashmakwana/motionmaxxing · Apache-2.0
- **Manim** (L): fórmulas e gráficos animados. https://github.com/ManimCommunity/manim · MIT
- **blender-skills** (L): truques de Blender para o Claude. https://github.com/EL4CTEO/blender-skills · MIT
- **three.quarks** (L): partículas em 3D. https://github.com/Alchemist0823/three.quarks · MIT
- **Tweakpane** (L): botões para ajustar cada detalhe. https://github.com/cocopon/tweakpane · MIT
- **EffectCraft** (L): composição e motion, em Rust. https://github.com/storytold/effectcraft · Apache-2.0
- **GSAP** (L): animação para web. https://github.com/greensock/GSAP · licença própria, gratuita

## Plugins do Claude
- **HyperFrames** (V): blocos prontos de animação. https://github.com/heygen-com/hyperframes · Apache-2.0
- **Lemo-Opuscar** (V): 99 estilos prontos. https://github.com/lemomo-ai/lemo-opuscar · licença própria
- **Superpowers** (V): método de trabalho com plano e conferência. https://github.com/obra/superpowers · MIT

## Som e voz
- **librosa** (V): acha cada batida da música. https://github.com/librosa/librosa · ISC
- **VoiceStudio** (V): clona a voz na sua máquina, sem pagar. https://github.com/debpalash/VoiceStudio · AGPL-3.0
- **ElevenLabs** (V): voz paga, por conector. https://elevenlabs.io
- **Openverse** (L): sons e imagens livres. https://openverse.org · conforme cada item
