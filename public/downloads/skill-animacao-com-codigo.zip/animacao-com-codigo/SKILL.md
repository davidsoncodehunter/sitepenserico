---
name: animacao-com-codigo
description: Anima telas, textos, produtos e vídeos em Remotion com acabamento profissional (grade preta viva, janelas de vidro, celular em destaque, vídeos passando atrás da pessoa, pessoa que cresce e sai da tela). Use quando pedirem "animação", "motion", "after effects com código", "animar por cima da minha fala", "deixar o vídeo mais estiloso" ou "colocar meus vídeos passando atrás".
---
# Animação com código

Regra de ouro: toda animação nasce na PALAVRA falada e explica a frase. Se tirar a animação e nada se perder, ela é enfeite: tire.

## Ordem
1. Transcreva a fala com tempo por palavra (Whisper) e faça a tabela: tempo | frase | o que aparece.
2. Escolha UM estado por trecho: PESSOA (gravação limpa), CANTO (escurece os lados e põe algo), PASSAGEM (vídeos atravessam atrás dela) ou TELA (gráfico cheio na grade). Nunca mais de 6 s no mesmo estado.
3. Mostre quadros parados. Só anime depois do OK.
4. Renderize, olhe 1 quadro por segundo e conserte.

## Movimento
- Entrada 0,6 a 0,9 s com `cubic-bezier(0.16,1,0.3,1)`; saída 0,35 s; troca de tela 0,45 s. Nada linear.
- Entra de um lado, com desfoque que some. Nunca só "fade".
- Um movimento principal por vez; o resto quase parado.
- O fundo sempre anda devagar. Preto com grade fina, luz no centro. Uma cor de destaque.
- Texto: uma ideia por vez, grande, sem pílula atrás, nunca em cima do rosto.
- Quem fala NÃO fica indo e vindo na tela. Cansa.
- Recorte da pessoa é tempero: só para algo passar atrás, até 4 s. Fora disso, a sala inteira.
- Vídeo em destaque: grande, no centro, vizinhos apagados. Escolha o trecho claro e colorido.
- Som: poucos efeitos e baixos; música por baixo só em alguns momentos.

## Peças prontas
`template/Pecas.tsx` (copie para `src/`): `Grade`, `Janela`, `Carrossel`, `Passa`, `Sai`, `Cantos`, `Digita`, `Numero`.

## Ferramentas que combinam
reanimate (entender uma animação), motion-design-skill (tempo e curva), mg-styles-15 e lemo-opuscar (estilos), cinetic (lançamento), motionmaxxing (tirar a cara de IA), HyperFrames (blocos prontos), react-postprocessing (luz e grão), three.quarks (partículas), Manim (fórmulas), librosa (batida).

## Antes de entregar
Nada cobre o rosto · nenhum clipe congelado no último quadro · texto lido em 1 s · contraste bom no celular · sem dado particular na tela (e-mail, histórico, barra lateral, notificações).
