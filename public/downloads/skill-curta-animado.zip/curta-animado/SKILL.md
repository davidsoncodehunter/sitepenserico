---
name: curta-animado
description: Cria CURTA-METRAGEM DE DESENHO ANIMADO em código (Remotion), de 20 s a 4 min, com personagem próprio, história, vilão, virada, som e capa para o YouTube. Use quando pedirem "curta animado", "desenho animado", "história animada para o YouTube", "vídeo de boneco", "animação 2D com personagem" ou "curta-metragem com o Claude".
---
# Curta animado em código

Explique cada passo em português simples antes de fazer. Só passe ao próximo depois do OK da pessoa.

## 0. Pergunte de uma vez só
1. Qual é a MENSAGEM, em uma frase? (ex.: "disciplina vence a preguiça")
2. Para quem é, e em que idioma?
3. Duração: 30 s, 1 min ou 3 min. Deitado (16:9) ou em pé (9:16)?
4. Tem referência (link)? Tem personagem? Se não tiver, crie 3 opções.
5. Tem produto para mostrar? Em qual momento da história ele ajuda?

## 1. Referência: estude a técnica, nunca copie o vídeo
Siga `referencias/ESTUDAR-REFERENCIA.md`. Sai uma tabela "tempo | o que acontece | por que prende".
Proibido repetir da referência: personagem, frase, sequência de cenas, título e capa.
Antes de renderizar, ponha lado a lado as suas frases e cenas e as dela. Igual, troca.

## 2. História
Use `referencias/ROTEIRO.md`. Toda história tem: desejo, vilão, preço, decisão, caminho difícil e final que paga o começo.
O vilão é uma IMAGEM (uma nota que não acaba, um balão que fala, caixas que pesam). A mensagem tem de ser entendida SEM SOM.
Mostre 3 finais possíveis e espere a escolha.

## 3. Personagem
- Desenho em CÓDIGO (`template/src/Boneco.tsx`) ou arte recortada em peças (cabeça, braço, antebraço, coxa, canela). Nunca um desenho inteiro parado.
- Fonte única: um arquivo só desenha o personagem. Toda cena importa esse arquivo.
- O que NUNCA muda: formato da cabeça, olhos, cor, um detalhe de marca. O que MUDA com a história: roupa, postura, energia (cor), rosto.
- Faça a ficha (`npm run ficha`): poses + rostos. Só anime depois do OK na ficha.

## 4. Quadros parados
Um quadro por cena, no motor de verdade. Monte uma folha numerada e mostre. Só anime depois do OK.

## 5. Animação (o que separa amador de profissional)
- Confira CADA pose: a cabeça segue a direção do corpo, o joelho dobra ao sentar, a mão TOCA o objeto, o cotovelo aponta para o lado certo.
- Nada fica morto: piscada, respiração, cabelo, poeira, vapor, luz que oscila.
- Antecipação antes do movimento, exagero no pico, acomodação no fim.
- Câmera com intenção: pelo menos 6 ângulos no curta (de cima, por trás do objeto, ponto de vista, por cima do ombro, câmera torta, primeiro plano).
- Luz conta a história: escuro no drama, clareia quando a personagem muda. A luz tem motivo (janela, celular, fogo) e recorta o rosto.
- O que passa atrás de porta, mesa ou cama usa recorte (`clipPath`). Confira com a porta MEIO fechada.
- Texto nunca em cima do rosto. Balão escreve letra por letra.

## 6. Som
- Escolha a música ANTES de animar. Marque as batidas (librosa) e ponha a virada da música na virada da história.
- Começa tensa e baixa, cresce, cai na parte difícil e vira forte quando a personagem muda. Troca de faixa só no silêncio ou no fim de uma frase musical.
- Efeito em tudo que toca: passo, porta, respiração, clique, vento. Sempre abaixo da voz.
- Voz: VoiceStudio (grátis, na sua máquina) ou ElevenLabs. Só voz sua ou autorizada.
- Use música com licença (Pixabay, Openverse) e anote nome, autor e link.

## 7. Capa
Fundo escuro, rosto grande com emoção forte, um objeto da história, 2 a 4 palavras brancas enormes. Teste em 168x94 px. Deixe livre o canto inferior direito.

## 8. Antes de entregar
Rode `scripts/conferir.sh video.mp4` e OLHE as folhas. Confira: quadro 0 forte, nenhuma pose quebrada, texto legível, volume perto de -14 LUFS, sem tela preta.
Entregue: vídeo, capa, título (até 60 letras), descrição com capítulos e 5 hashtags.

## Rodar
Copie `template/` para uma pasta nova:
```
npm install
npm run estudio      # ver e ajustar
npm run ficha        # ficha do personagem
npm run render       # curta de exemplo
```
O exemplo é só o esqueleto. Crie o SEU personagem e a SUA história.
