# Estudar uma referência sem copiar
1. Baixe só a legenda: `yt-dlp --skip-download --write-auto-subs --sub-langs "pt,en" "LINK"`. Se precisar do vídeo para estudo, use apenas o que a plataforma permite.
2. Folha de quadros: 1 quadro a cada 0,5 s; nas trocas de cena, 12 por segundo.
3. Meça: quantas novidades a cada 10 s, quanto tempo o rosto aparece grande, onde entra música, onde há silêncio.
4. Tabela: tempo | o que se vê | o que se ouve | por que prende.
5. Escreva 10 REGRAS de técnica (corte, luz, câmera, ritmo, som). É só isso que você leva.
6. Lista do que NÃO pode ser repetido: personagem, frases, números, ordem das cenas, título, capa.
