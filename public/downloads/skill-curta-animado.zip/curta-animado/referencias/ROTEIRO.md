# Roteiro do curta (modelo de 3 minutos; corte à metade para 1 min)
| Parte | Tempo | O que precisa acontecer |
|---|---|---|
| Gancho | 0:00–0:08 | a imagem mais forte e a pergunta. Rosto grande no 1º quadro |
| Vida de hoje | 0:08–0:30 | o hábito, o vilão aparece pequeno e simpático |
| Preço | 0:30–1:00 | o vilão cresce; a personagem perde algo concreto |
| Fundo do poço | 1:00–1:15 | silêncio curto, a pior imagem |
| Decisão | 1:15–1:25 | um gesto mínimo. A música vira AQUI |
| Caminho | 1:25–2:30 | tentativa, queda, volta. Cada vez diferente. O corpo, a luz e a cor mudam |
| Confronto | 2:30–2:45 | o vilão volta; a resposta é uma AÇÃO, não uma fala |
| Final | 2:45–3:00 | paga a primeira cena; companhia, não solidão; frase curta |

## Regras
- Uma ideia só. Se a frase não ajuda a mensagem, sai.
- Conte com ação e objeto. Narração curta, frase de gente.
- Cada 3 a 6 s algo novo na tela, mas deixe respirar no drama.
- Produto entra como ajuda, dentro da ação, nunca como propaganda no meio.
- Nunca repita a fórmula do curta anterior: outro vilão, outro objeto, outra virada, outro final.

## Folha de cenas (preencha antes de animar)
`nº | tempo | ângulo | o que acontece | rosto | luz | som | texto`
