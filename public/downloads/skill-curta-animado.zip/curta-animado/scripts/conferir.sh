#!/bin/sh
# uso: sh conferir.sh video.mp4  (precisa do ffmpeg)
v="$1"; [ -f "$v" ] || { echo "diga o vídeo: sh conferir.sh video.mp4"; exit 1; }
ffprobe -v error -show_entries stream=width,height,r_frame_rate,codec_name:format=duration -of default=nw=1 "$v"
ffmpeg -v error -y -i "$v" -vf "fps=2,scale=320:-2,tile=6x8" folha_%02d.jpg
ffmpeg -v error -y -i "$v" -frames:v 1 quadro_0.jpg
ffmpeg -hide_banner -i "$v" -vf blackdetect=d=0.3:pix_th=0.02 -an -f null - 2>&1 | grep blackdetect || echo "sem tela preta"
ffmpeg -hide_banner -i "$v" -af ebur128=peak=true -f null - 2>&1 | grep -E "I:|Peak:" | tail -2
echo "abra quadro_0.jpg e as folha_*.jpg e olhe pose por pose"
