import React from "react";
/* PERSONAGEM DE EXEMPLO (troque pelo seu). Este é o ÚNICO arquivo que desenha o personagem.
 * Pose = quadril, mãos e pés; braços e pernas se dobram sozinhos (cinemática inversa). */
export type Rosto = "ok" | "feliz" | "triste" | "sono" | "susto" | "forca";
export type Pose = { hip: [number, number]; lean?: number; head?: number; mE: [number, number]; mD: [number, number]; pE: [number, number]; pD: [number, number]; rosto?: Rosto; energia?: number; pisca?: boolean; roupa?: string };
const mix = (a: string, b: string, t: number) => "#" + [1, 3, 5].map((i) => Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - t) + parseInt(b.slice(i, i + 2), 16) * t).toString(16).padStart(2, "0")).join("");
/** dobra em dois segmentos: a = início, b = alvo */
export const ik = (a: [number, number], b: [number, number], l1: number, l2: number, lado: number): [[number, number], [number, number]] => {
  const dx = b[0] - a[0], dy = b[1] - a[1], d = Math.min(Math.hypot(dx, dy), l1 + l2 - 0.5), t = Math.atan2(dy, dx), g = Math.acos(Math.max(-1, Math.min(1, (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d)))) * lado;
  return [[a[0] + l1 * Math.cos(t + g), a[1] + l1 * Math.sin(t + g)], [a[0] + d * Math.cos(t), a[1] + d * Math.sin(t)]];
};
const L = (ps: number[][], w: number, c: string) => <path d={"M" + ps.map((p) => p.map((v) => v.toFixed(1)).join(" ")).join("L")} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" />;
export const Boneco: React.FC<Pose> = ({ hip, lean = 0, head = 0, mE, mD, pE, pD, rosto = "ok", energia = 1, pisca, roupa = "#2F6F8F" }) => {
  const cor = mix("#8c939b", "#4FB0A5", energia), esc = mix("#6d747c", "#35897f", energia), r = (lean * Math.PI) / 180;
  const loc = (x: number, y: number): [number, number] => [hip[0] + x * Math.cos(r) - y * Math.sin(r), hip[1] + x * Math.sin(r) + y * Math.cos(r)];
  const perna = (dx: number, p: [number, number], c: string) => { const s = loc(dx, 0), [k, f] = ik(s, p, 72, 72, -1); return <g>{L([s, k, f], 34, c)}{L([[f[0] - 8, f[1]], [f[0] + 26, f[1]]], 28, "#20242a")}</g>; };
  const braco = (dx: number, m: [number, number], c: string, lado: number) => { const s = loc(dx, -92), [e, h] = ik(s, m, 56, 56, lado); return <g>{L([s, e, h], 27, c)}<circle cx={h[0]} cy={h[1]} r={17} fill={c} /></g>; };
  const H = loc(2, -172), X = "#16181c", tr = { fill: "none", stroke: X, strokeWidth: 7, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const olho = (x: number) => pisca ? <path d={`M${x - 13} 0q13 8 26 0`} {...tr} /> : <g><ellipse cx={x} cy={0} rx={11} ry={15} fill={X} /><circle cx={x + 4} cy={-6} r={4.4} fill="#fff" /></g>;
  const R: Record<Rosto, React.ReactNode> = {
    ok: <>{olho(-28)}{olho(28)}<path d="M-12 30q12 10 24 0" {...tr} /></>,
    feliz: <><path d="M-42 4q14 -20 28 0M14 4q14 -20 28 0" {...tr} /><path d="M-18 24Q0 30 18 24Q16 48 0 48Q-16 48 -18 24Z" fill={X} /></>,
    triste: <>{olho(-28)}{olho(28)}<path d="M-46 -26l24 -8M46 -26l-24 -8M-12 38q12 -12 24 0" {...tr} /></>,
    sono: <><path d="M-42 2q14 11 28 0M14 2q14 11 28 0" {...tr} /><ellipse cx={0} cy={34} rx={8} ry={7} fill={X} /></>,
    susto: <>{[-28, 28].map((x) => <g key={x}><circle cx={x} cy={-2} r={20} fill="#fff" /><circle cx={x + 2} cy={-1} r={7} fill={X} /></g>)}<ellipse cx={0} cy={38} rx={11} ry={14} fill={X} /></>,
    forca: <><path d="M-42 -10l22 9l-22 9M42 -10l-22 9l22 9" {...tr} /><rect x={-20} y={26} width={40} height={18} rx={7} fill="#fff" stroke={X} strokeWidth={5} /></>,
  };
  return (
    <g>
      {braco(26, mD, esc, 1)}{perna(14, pD, "#20344a")}{perna(-13, pE, "#2a4460")}
      <g transform={`translate(${hip[0]} ${hip[1]}) rotate(${lean})`}><path d="M-38 12Q-46 -60 -40 -96Q-34 -112 0 -112Q34 -112 40 -96Q46 -60 38 12Q0 24 -38 12Z" fill={roupa} /><path d="M-40 -96Q-34 -112 0 -112Q34 -112 40 -96Q0 -82 -40 -96Z" fill="rgba(255,255,255,.18)" /></g>
      {braco(-27, mE, cor, 1)}
      <g transform={`translate(${H[0]} ${H[1]}) rotate(${head})`}><rect x={-74} y={-72} width={148} height={146} rx={66} fill={cor} /><path d="M-74 2Q-74 -72 0 -72Q-46 -50 -46 4Q-46 58 -10 74Q-74 66 -74 2Z" fill={esc} opacity={0.5} /><path d="M-6 -70q4 -30 30 -26q-10 10 -4 24z" fill={cor} /><circle cx={-50} cy={26} r={13} fill="#ff7a7a" opacity={0.35} /><circle cx={50} cy={26} r={13} fill="#ff7a7a" opacity={0.35} /><g transform="translate(4 4)">{R[rosto]}</g></g>
    </g>
  );
};
/** corrida/caminhada: fase em radianos, v = 0 (anda) a 1 (corre) */
export const passo = (x: number, chao: number, fase: number, v = 0): Pick<Pose, "hip" | "lean" | "mE" | "mD" | "pE" | "pD"> => {
  const hip: [number, number] = [x, chao - 132 - Math.abs(Math.sin(fase)) * (6 + 12 * v)], a = 46 + 34 * v;
  const pe = (f: number): [number, number] => [x + Math.cos(f) * a, chao - Math.max(0, Math.sin(f)) * (26 + 44 * v)];
  const mao = (f: number): [number, number] => [x + 26 * v + Math.cos(f) * (44 + 22 * v), hip[1] - 34 - 22 * v - Math.sin(f) * 16];
  return { hip, lean: 4 + 12 * v, pE: pe(fase), pD: pe(fase + Math.PI), mE: mao(fase + Math.PI), mD: mao(fase) };
};
