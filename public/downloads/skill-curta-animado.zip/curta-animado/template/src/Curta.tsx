import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate } from "remotion";
import { Boneco, passo } from "./Boneco";
import { Cena, Narrador, Balao, CL, k } from "./Pecas";
/* CURTA DE EXEMPLO, 20 s. Cada cena = um trecho de tempo. Troque pela SUA história (veja referencias/ROTEIRO.md). */
export const Curta: React.FC = () => {
  const f = useCurrentFrame(), t = f / 30, pisca = Math.floor(t * 30) % 96 < 4, res = Math.sin(t * 2.2) * 3;
  const c1 = t < 6, c2 = t >= 6 && t < 11, c3 = t >= 11;
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      {c1 && <div style={{ transform: `scale(${1.35 + t * 0.02})`, transformOrigin: "46% 62%", width: 1920, height: 1080 }}><Cena clima={0} luzX={1250}>
        <rect x={560} y={720} width={620} height={190} rx={40} fill="#1b2233" /><rect x={560} y={600} width={130} height={300} rx={40} fill="#222b40" />
        <Boneco hip={[860, 740 + res]} lean={-6} head={10} mE={[940, 720]} mD={[960, 726]} pE={[1010, 890]} pD={[1050, 890]} rosto="sono" energia={0.1} pisca={pisca} roupa="#5b6270" />
        <rect x={930} y={660} width={46} height={84} rx={8} fill="#0e1320" stroke="#7fd4ff" strokeWidth={4} />
        <Balao t={t} em={1.6} x={1260} y={420} esc={0.7 + 0.12 * t} texto="amanhã..." /></Cena></div>}
      {c2 && <div style={{ transform: `rotate(${-2 + (t - 6) * 0.5}deg) scale(1.12)`, width: 1920, height: 1080 }}><Cena clima={0.25} luzX={960}>
        <Balao t={t} em={6} x={1180} y={420} esc={1.6 - k(t, 9, 1.2) * 1.1} texto="amanhã!" />
        <Boneco hip={[720, 728]} lean={4} head={t > 8 ? -4 : 8} mE={[660, 720]} mD={t > 8.4 ? [900, 560] : [790, 730]} pE={[680, 872]} pD={[770, 872]} rosto={t > 8.4 ? "forca" : "triste"} energia={interpolate(t, [8.4, 10], [0.2, 0.6], CL)} pisca={pisca} roupa="#5b6270" /></Cena></div>}
      {c3 && <Cena clima={interpolate(t, [11, 13], [0.3, 1], CL)} luzX={1500}>
        {Array.from({ length: 9 }, (_, i) => { const x = ((i * 300 - t * 260) % 2700 + 2700) % 2700 - 300; return <g key={i}><rect x={x} y={860 - 190 - (i % 3) * 70} width={150} height={190 + (i % 3) * 70} rx={14} fill="#1f5063" /><rect x={x + 40} y={720 - (i % 3) * 60} width={26} height={36} rx={6} fill="#FFE3A8" opacity={0.8} /></g>; })}
        <rect y={860} width={1920} height={220} fill="#173447" /><ellipse cx={900} cy={872} rx={110} ry={16} fill="rgba(0,0,0,.35)" />
        <Boneco {...passo(900, 862, t * 9, k(t, 12, 2))} head={-4} rosto={t > 15 ? "feliz" : "forca"} energia={interpolate(t, [11, 16], [0.6, 1], CL)} pisca={pisca} roupa="#E07A3F" /></Cena>}
      <Narrador t={t} em={0.6} ate={5.6} texto="Ele sempre deixava para amanhã." />
      <Narrador t={t} em={8.2} ate={10.9} texto="Até o dia em que respondeu." />
      <Narrador t={t} em={15.4} ate={19.6} texto="Amanhã nunca chega. Comece hoje." />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,.55))" }} />
      <AbsoluteFill style={{ background: "#fff", opacity: interpolate(t, [10.9, 11, 11.27], [0, 0.85, 0], CL) }} />
    </AbsoluteFill>
  );
};
