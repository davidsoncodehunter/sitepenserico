import React from "react";
import { Boneco, passo, Rosto } from "./Boneco";
const RS: Rosto[] = ["ok", "feliz", "triste", "sono", "susto", "forca"];
export const Ficha: React.FC = () => (
  <svg width={1920} height={1080} style={{ background: "#10141f" }}>
    <text x={70} y={96} fill="#fff" fontFamily="Inter, Arial" fontWeight={800} fontSize={54}>Ficha do personagem</text>
    {RS.map((r, i) => <g key={r} transform={`translate(${230 + i * 290} 0)`}><Boneco hip={[0, 420]} mE={[-70, 420]} mD={[70, 420]} pE={[-24, 562]} pD={[30, 562]} rosto={r} energia={i / 5} /><text x={0} y={632} textAnchor="middle" fill="#9aa4b8" fontFamily="Inter, Arial" fontSize={30}>{r}</text></g>)}
    {[0, 1, 2, 3, 4, 5].map((i) => <g key={i}><Boneco {...passo(230 + i * 290, 980, (i / 6) * Math.PI * 2, i > 2 ? 1 : 0)} energia={1} rosto={i > 2 ? "forca" : "ok"} /></g>)}
  </svg>
);
