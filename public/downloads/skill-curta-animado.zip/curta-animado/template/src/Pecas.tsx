import React from "react";
import { interpolate, Easing } from "remotion";
export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
export const k = (t: number, a: number, d = 0.7) => interpolate(t, [a, a + d], [0, 1], { ...CL, easing: Easing.bezier(0.16, 1, 0.3, 1) });
export const vis = (t: number, a: number, b: number, d = 0.4) => k(t, a, d) * (1 - k(t, b - d, d));
/** quarto/rua com luz de motivo: clima 0 = drama escuro, 1 = claro */
export const Cena: React.FC<{ clima: number; luzX?: number; children: React.ReactNode }> = ({ clima, luzX = 1300, children }) => (
  <svg width={1920} height={1080} style={{ position: "absolute" }}>
    <defs><radialGradient id="lz" cx={luzX / 1920} cy={0.42} r={0.62}><stop offset="0" stopColor={clima > 0.5 ? "#FFE3A8" : "#FFB36B"} stopOpacity={0.5 + 0.4 * clima} /><stop offset="1" stopColor="#0a0d16" stopOpacity={0} /></radialGradient></defs>
    <rect width={1920} height={1080} fill={clima > 0.5 ? "#27506a" : "#0b0e17"} /><rect width={1920} height={1080} fill="url(#lz)" />
    <rect y={860} width={1920} height={220} fill={clima > 0.5 ? "#173447" : "#07090f"} />{children}
  </svg>
);
/** narrador: palavra por palavra, do borrão ao nítido */
export const Narrador: React.FC<{ t: number; em: number; ate: number; texto: string }> = ({ t, em, ate, texto }) => t < em || t > ate ? null : (
  <div style={{ position: "absolute", left: 160, right: 160, bottom: 70, textAlign: "center", fontFamily: "Inter, Arial, sans-serif", fontWeight: 700, fontSize: 62, color: "#fff", textShadow: "0 4px 26px #000", opacity: 1 - k(t, ate - 0.35, 0.35) }}>
    {texto.split(" ").map((p, i) => { const q = k(t, em + i * 0.16, 0.4); return <span key={i} style={{ opacity: q, filter: `blur(${(1 - q) * 10}px)`, marginRight: 16, display: "inline-block" }}>{p}</span>; })}
  </div>
);
/** o vilão de exemplo: um balão que cresce e escreve letra por letra */
export const Balao: React.FC<{ t: number; em: number; x: number; y: number; esc: number; texto: string }> = ({ t, em, x, y, esc, texto }) => (
  <g transform={`translate(${x} ${y + Math.sin(t * 2) * 8}) scale(${esc * (0.6 + 0.4 * k(t, em, 0.6))})`} opacity={k(t, em, 0.3)}>
    <path d="M-210 -120Q-230 -190 0 -190Q230 -190 230 -60Q230 60 20 62Q-20 110 -80 128Q-62 92 -74 58Q-230 40 -210 -120Z" fill="#0a0608" stroke="#ff3b4e" strokeWidth={8} />
    <text x={4} y={-40} textAnchor="middle" fill="#fff" fontFamily="Inter, Arial" fontWeight={800} fontSize={72}>{texto.slice(0, Math.floor(Math.max(0, t - em - 0.3) * 14))}</text>
  </g>
);
