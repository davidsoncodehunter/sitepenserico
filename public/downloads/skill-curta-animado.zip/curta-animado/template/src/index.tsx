import React from "react";
import { registerRoot, Composition, Still } from "remotion";
import { Curta } from "./Curta";
import { Ficha } from "./Ficha";
registerRoot(() => (<><Composition id="Curta" component={Curta} durationInFrames={600} fps={30} width={1920} height={1080} /><Still id="Ficha" component={Ficha} width={1920} height={1080} /></>));
