---
name: edicao-com-claude
description: Edita gravação longa ou curta de pessoa falando (aula, tutorial, reels) - transcreve, corta erro e pausa sem comer palavra, trata cor e áudio, enquadra a tela gravada, esconde dado particular, põe animação por cima e confere tudo. Use quando pedirem "edita meu vídeo", "corta os erros da minha fala", "monta minha aula do YouTube" ou "deixa meu vídeo profissional".
---
# Edição de fala com o Claude

## Ordem (não pule)
1. **Nunca mexa no original.** Trabalhe numa cópia leve (1080p).
2. **Transcreva** com tempo por palavra (Whisper) e leia tudo antes de cortar.
3. **Lista de cortes:** só erro, retomada e espera. Frase que completa o raciocínio fica. Na dúvida, fica.
4. **Corte onde o som cai de verdade**, nunca no tempo da palavra do Whisper: `python3 scripts/silencios.py audio.wav`. Pausa de 0,2 s não vale corte.
5. **Confira cada emenda:** `python3 scripts/emendas.py video_cortado.mp4 cortes.json`. Leia em voz alta; se faltar sílaba, abra o corte 0,1 s.
6. **Som:** reparar estouro (`adeclip`), tirar grave (`highpass=f=70`), voz no centro. Música 30 dB abaixo da fala e só em alguns momentos; efeito raro. Final em -14 LUFS, pico -1.
7. **Cor:** pele natural primeiro. Luz colorida que pisca distrai: neutralize. Uma cor de ambiente só.
8. **Tela gravada:** fundo com grade, tela grande num quadro, pessoa no outro, zoom no que importa.
9. **Privacidade:** olhe 1 quadro por segundo. Esconda e-mail, barra lateral, histórico de busca, notificação, nome de cliente, senha, chave.
10. **Animação** com a skill `animacao-com-codigo`.
11. **Entrega:** começa já falando, sem espera. Capítulos, título, descrição, capa.

## Regras que aprendemos errando
- Começar o vídeo já na fala. A espera do começo sai.
- Não recortar a pessoa o tempo todo: fica pobre. Recorte só para algo passar atrás.
- Câmera parada. Quem se mexe são os elementos.
- Música alta atrapalha. Se não tiver certeza, mais baixo.
- Imagem tratada e máscara precisam ter os MESMOS quadros por segundo (no ffmpeg, imagem em loop pede `-framerate 30`).
- Renderize vídeo longo em pedaços: se um falhar, não perde o resto.
