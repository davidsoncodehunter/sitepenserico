"""Transcreve 3,5 s antes e 4 s depois de cada emenda, para achar palavra comida.
uso: python3 emendas.py video_cortado.mp4 cortes.json [modelo.bin]
cortes.json = lista dos segundos do vídeo CORTADO onde há emenda. Ex.: [12.4, 33.9]
Precisa do ffmpeg e do whisper.cpp (whisper-cli)."""
import sys, json, subprocess, os
v, c = sys.argv[1], json.load(open(sys.argv[2])); m = sys.argv[3] if len(sys.argv) > 3 else os.path.expanduser("~/.cache/whisper.cpp/ggml-large-v3-turbo.bin")
for t in c:
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", str(max(0, t - 3.5)), "-t", "7.5", "-i", v, "-ac", "1", "-ar", "16000", "_emenda.wav"], check=True)
    r = subprocess.run(["whisper-cli", "-m", m, "-l", "pt", "-nt", "-np", "_emenda.wav"], capture_output=True, text=True).stdout.strip()
    print(f"{t:8.2f}: {r}")
os.path.exists("_emenda.wav") and os.remove("_emenda.wav")
