"""Lista as pausas pela energia do som. uso: python3 silencios.py audio_16k.wav [db=-28] [min=0.7]   (gere com: ffmpeg -i video.mp4 -ac 1 -ar 16000 audio_16k.wav)"""
import sys, wave, array, math
w = wave.open(sys.argv[1]); assert w.getnchannels() == 1 and w.getsampwidth() == 2, "use mono 16 bits: ffmpeg -i video.mp4 -ac 1 -ar 16000 audio_16k.wav"
lim = float(sys.argv[2]) if len(sys.argv) > 2 else -28; mn = float(sys.argv[3]) if len(sys.argv) > 3 else 0.7
sr = w.getframerate(); x = array.array("h", w.readframes(w.getnframes())); n = sr // 50; db = []
for i in range(0, len(x) - n, n): db.append(20 * math.log10(math.sqrt(sum(v * v for v in x[i:i + n]) / n) / 32768 + 1e-6))
db = [sum(db[max(0, i - 2):i + 3]) / len(db[max(0, i - 2):i + 3]) for i in range(len(db))]
i = 0
while i < len(db):
    if db[i] < lim:
        j = i
        while j < len(db) and db[j] < lim: j += 1
        if (j - i) / 50 >= mn: print(f"{i/50:8.2f} -> {j/50:8.2f}   ({(j-i)/50:.2f} s)   corte seguro: {i/50+.22:.2f} a {j/50-.2:.2f}")
        i = j
    else: i += 1
