---
name: video-lancamento
description: Cria vídeo de lançamento de UMA função de um app ou produto (estilo comercial de tecnologia), em Remotion, com o mesmo código saindo deitado 16:9 e em pé 9:16. Use quando pedirem "vídeo de função", "vídeo de lançamento", "vídeo de feature", "anúncio da funcionalidade" ou "explicar a função do app em vídeo".
---
# Vídeo de lançamento de função

Uma função por vídeo. Quem assiste **sem som** entende a pergunta, o toque, o que o app faz e o resultado.

## Antes de tudo (pergunte o que faltar, de uma vez só)
1. Qual função, e qual tela real (peça prints).
2. Qual pergunta a pessoa não sabe responder e a função responde.
3. O caminho exato no app: cada toque, com o nome do botão igual ao da tela.
4. Takes de gente de verdade (dela ou de banco livre), marca, cores e música com licença.
5. Deitado, em pé ou os dois.

Nunca invente tela, botão, número ou resultado. Número de exemplo fecha a conta e vai marcado como exemplo.

## Ordem de trabalho (não pule)
1. **Referência:** se houver, estude quadro a quadro (`referencias/ESTUDAR-REFERENCIA.md`). Vale a técnica; nunca a sequência, o texto, a abertura ou o visual.
2. **Roteiro** em 8 a 10 cenas (`referencias/ROTEIRO.md`). Mostre e espere o OK.
3. **Quadros parados:** um quadro por cena, no motor de verdade. Mostre numa folha numerada e espere o OK. Só depois anime.
4. **Animação** com os efeitos de `template/src/efeitos.tsx` (`referencias/EFEITOS.md`).
5. **Som:** música por momento; a virada da música cai na virada da história; efeito só no toque e no corte.
6. **Conferir:** `scripts/conferir.sh video.mp4` e olhar a folha de quadros dos DOIS formatos.

## Regras que não mudam
- Um OBJETO atravessa o vídeo e vira a próxima cena. Nada de slide atrás de slide.
- Cada toque CAUSA a próxima cena.
- Coisa real antes de boneco: gente, objeto e comida de verdade; 3D só para o que não dá para filmar.
- Uma informação por vez. Cada instrução fica no mínimo 1,3 s na tela, curta e no imperativo: "Aperte o play."
- De 30% a 45% do tempo quase parado, para ler.
- Texto grande, nunca em cima de rosto. Número sempre com o nome escrito.
- Uma história pequena com queda e volta.
- Quadro 0 já é a capa: forte, sem tela preta e sem fade.
- Cada vídeo com um mundo visual diferente do anterior.

## Como rodar
Copie `template/` para uma pasta nova e, dentro dela:
```
npm install
npm run estudio
npm run deitado
npm run em-pe
```
`src/formato.ts` escolhe o valor de cada formato: `f(valorDeitado, valorEmPe)`. Nunca corte o deitado para fazer o em pé: reposicione.
