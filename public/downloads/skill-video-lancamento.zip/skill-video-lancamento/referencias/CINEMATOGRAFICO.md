# Cinematográfico de frase (7 a 20 s)
Serve para marca e emoção. Não explica função.
1. **Frase curta** que a pessoa diria para si mesma. Nada de conselho genérico. Duas linhas no máximo.
2. **40 ou mais cenas reais, sem repetir**, 4 a 6 quadros cada. Olhe cada vídeo inteiro antes e use só o trecho bom (sem ajeitar câmera, sem outra pessoa ao fundo).
3. **Alterne**: rosto, mão, detalhe, pessoa longe, objeto, movimento. Homem e mulher, se fizer sentido.
4. **Quadro 0 = capa**: a imagem mais forte, desfocada com intenção, SEM texto. A frase entra depois.
5. **Duas cores**: a parte da dor em azul-marinho, a vitória em creme. **Negativo** de 2 quadros a cada 7 cortes.
6. **Corte na batida**. Música contínua: se ela para, tem que ser o momento mais importante do vídeo; senão, não pare.
7. **Fim**: logo, 1,2 s.
Arquivo: `template/src/Frase.tsx` (troque CENAS, FRASE e MARCA). Comandos: `npm run frase` (em pé) e `npm run frase-deitado`.
