# Os 10 efeitos (30 quadros por segundo)
| Efeito | Componente | Quando | Duração |
|---|---|---|---|
| Palavras que saem do borrão | `Palavras` | instrução e fecho | 4 quadros entre palavras, 12 para cada |
| Mergulho na letra | `Mergulho` | da pergunta para a 1ª cena | 34 a 38 quadros |
| Negativo | `Negativo` | no corte forte | 2 quadros, no máximo 3 vezes no vídeo |
| Borrão radial | `Radial` | na virada da música | 10 a 14 quadros |
| Rastro | `Rastro` | movimento de gente | 5 cópias, 2 quadros de atraso |
| Dedo que toca | `Dedo` | toda ação no app | chega em 14, aperta em 3 |
| Botão que vira a cena | `BotaoVira` | depois do toque | rótulo, estado ("Contando…"), cresce em 20 |
| Linha de luz | `LinhaLuz` | objeto que atravessa tudo | 40 a 60 quadros |
| Número que rola | `Numero` | resultado | 36 a 44 quadros |
| Risco à mão | `Risco` | o dado que responde a pergunta | 16 quadros |
| Objeto que pousa | `Pousa` | foto vira check, peça entra na lista | 22 quadros |

Regras: entrada freia (`freia`), saída acelera (`acelera`). Um efeito dominante por cena. Nada some seco, nada nasce parado.
