# Estudar uma referência sem copiar
1. Folha com 4 quadros por segundo do vídeo inteiro. Em cada transição, 16 a 22 por segundo.
2. Meça: quanto tempo fica quase parado, cortes por 10 s, volume (LUFS), onde a música entra.
3. Para cada efeito, escreva: de onde sai, para onde vai, quantos quadros, o que acontece com borrão, escala e opacidade.
4. Escreva a lista do que é PROIBIDO repetir: ordem das cenas, abertura, frases, cores, nomes, layout.
5. Guarde só as técnicas e troque o objeto, a história e o mundo.
