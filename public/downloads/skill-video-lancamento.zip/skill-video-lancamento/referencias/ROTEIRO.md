# Roteiro de 8 a 10 cenas
| Cena | O que faz | Exemplo (Corrida) |
|---|---|---|
| 1 Pergunta | a pessoa não sabe responder | "Onde você acelerou?" |
| 2 Entrada | o objeto do vídeo entra no celular | o cadarço vira a linha |
| 3 Toque | instrução + dedo | "Aperte o play." |
| 4 Virada | a música entra, o botão vira mundo | sinal verde: "Vai." |
| 5 Gente | a ação de verdade | ela correndo, a linha sai dela |
| 6 O app faz | o que só o app mostra | a cidade acende no caminho |
| 7 Resultado | número com nome, um por vez | 5,02 km, 28:37 |
| 8 Detalhe | o dedo acha a resposta | km 3, seu trecho mais rápido |
| 9 Queda e volta | o dia ruim e o recomeço | três semanas sem correr |
| 10 Resposta | responde a cena 1 + marca | "Agora você sabe onde acelerou." |

Teste: tape o som e mostre para alguém. Ela diz em uma frase o que a função faz? Se não, tire uma informação.
