#!/bin/bash
# uso: ./conferir.sh video.mp4   -> confere tamanho, volume, tela preta, metadado e monta a folha de quadros
set -e; V="$1"; B="${V%.*}"
ffprobe -v error -select_streams v -show_entries stream=width,height,r_frame_rate:format=duration,size -of default=nw=1 "$V"
echo "--- volume (alvo -14 LUFS)"; ffmpeg -hide_banner -nostats -i "$V" -af ebur128 -f null - 2>&1 | grep -E "I:|Peak:" | tail -2 || echo "sem som"
echo "--- tela preta por mais de 0,15 s"; ffmpeg -hide_banner -nostats -i "$V" -vf blackdetect=d=0.15:pix_th=0.02:pic_th=0.998 -an -f null - 2>&1 | grep black_start || echo "nenhuma"
echo "--- metadado"; ffprobe -v error -show_entries format_tags=title,comment,artist -of default=nw=1 "$V"
ffmpeg -v error -y -i "$V" -vf "fps=2,scale=240:-1,tile=8x8" -frames:v 1 -update 1 "${B}_folha.png"; echo "folha: ${B}_folha.png"
