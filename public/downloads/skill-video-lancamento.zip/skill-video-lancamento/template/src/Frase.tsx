// CINEMATOGRÁFICO DE FRASE: muitos cortes rápidos + uma frase parada + marca no fim. Funciona em pé e deitado.
// 1) ponha as SUAS cenas em public/cenas/ (001.jpg, 002.jpg... ou .mp4) e troque a lista CENAS. 2) troque FRASE e MARCA.
import React from 'react';
import { AbsoluteFill, Img, OffthreadVideo, Sequence, staticFile, useCurrentFrame } from 'remotion';
import { useFormato } from './formato';
import { freia, vai } from './efeitos';
export const FRASE = ['SUA', 'FRASE', 'AQUI.'];              // uma palavra (ou duas) por vez
export const MARCA = 'SUA MARCA';
export const CENAS: string[] = [];                             // ex.: ['cenas/001.jpg', 'cenas/002.mp4#3.5'] (#3.5 = começa em 3,5 s; vazio = cenas de exemplo desenhadas)
const CAPA = 10;                                               // quadros iniciais: imagem forte, desfocada, SEM texto (é a capa do post)
const CORTE = 5;                                               // quadros por cena (4 a 6 = rápido)
const TOTAL_CENAS = 44, FIM = 46; export const DURACAO_FRASE = CAPA + TOTAL_CENAS * CORTE + FIM;
const NAVY = '#0d1b36', CREME = '#efe6d2';
const sorte = (n: number) => { const x = Math.sin(n * 127.1) * 43758.5453; return x - Math.floor(x); };
const Exemplo: React.FC<{ n: number; q: number }> = ({ n, q }) => { const a = sorte(n), b = sorte(n + 50), c = sorte(n + 90); return <AbsoluteFill style={{ background: `linear-gradient(${a * 180}deg, #555, #111)` }}><div style={{ position: 'absolute', left: `${10 + a * 50}%`, top: `${15 + b * 40}%`, width: '46%', height: '46%', borderRadius: c > 0.5 ? '50%' : '8%', background: 'radial-gradient(circle at 35% 30%, #fff, #777 60%, #222)', transform: `translate(${(q % CORTE) * (b > 0.5 ? 7 : -7)}px, 0) rotate(${c * 90}deg)` }} /><div style={{ position: 'absolute', left: 0, right: 0, bottom: `${c * 30}%`, height: '12%', background: '#000', transform: `skewY(${(a - 0.5) * 30}deg)` }} /></AbsoluteFill>; };
const Cena: React.FC<{ n: number; q: number }> = ({ n, q }) => { if (!CENAS.length) return <Exemplo n={n} q={q} />; const s = CENAS[n % CENAS.length]; const st: React.CSSProperties = { width: '100%', height: '100%', objectFit: 'cover' }; const [arq, ini] = s.split('#'); const de = q < CAPA ? 0 : CAPA + n * CORTE; return /\.(mp4|mov|webm)$/i.test(arq) ? <Sequence key={de} from={de} layout="none"><OffthreadVideo src={staticFile(arq)} startFrom={Math.round((Number(ini) || 0) * 30)} muted style={st} /></Sequence> : <Img src={staticFile(arq)} style={st} />; };
/** duas cores chapadas: sombra = NAVY ou preto, luz = CREME. dor = escuro, vitória = claro */
const Duas: React.FC<{ claro: boolean; children: React.ReactNode }> = ({ claro, children }) => <AbsoluteFill><AbsoluteFill style={{ filter: 'grayscale(1) contrast(1.55)' }}>{children}</AbsoluteFill><AbsoluteFill style={{ background: claro ? CREME : '#7f9bd1', mixBlendMode: 'multiply' }} /><AbsoluteFill style={{ background: NAVY, mixBlendMode: claro ? 'screen' : 'lighten', opacity: claro ? 0.55 : 1 }} /></AbsoluteFill>;
export const Frase: React.FC = () => {
  const q = useCurrentFrame(), { f } = useFormato(); const k = Math.floor((q - CAPA) / CORTE), noFim = k >= TOTAL_CENAS, capa = q < CAPA; const n = capa ? 3 : Math.max(0, k); const claro = k >= TOTAL_CENAS * 0.6; const dentro = (q - CAPA) % CORTE;
  const negativo = !capa && !noFim && k % 7 === 3 && dentro < 2; const zoom = 1.06 + (capa ? q * 0.004 : dentro * 0.012); const ini = CAPA + 24, passo = Math.floor((TOTAL_CENAS * CORTE - 40) / (FRASE.length + 1)); const quantas = Math.min(FRASE.length, Math.floor((q - ini) / passo) + 1);
  if (noFim) { const t = vai(q, CAPA + TOTAL_CENAS * CORTE, CAPA + TOTAL_CENAS * CORTE + 14, freia); return <AbsoluteFill style={{ background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'Inter, system-ui, sans-serif' }}><div style={{ fontSize: f(130, 108), fontWeight: 800, letterSpacing: '-0.03em', transform: `scale(${1.8 - 0.8 * t})`, opacity: t, filter: `blur(${18 * (1 - t)}px)` }}>{MARCA}</div></AbsoluteFill>; }
  return <AbsoluteFill style={{ background: '#000', overflow: 'hidden', filter: negativo ? 'invert(1)' : undefined }}><AbsoluteFill style={{ transform: `scale(${zoom + (capa ? 0.1 : 0)})`, filter: capa ? `blur(${18 - q}px)` : undefined }}><Duas claro={claro}><Cena n={n} q={q} /></Duas></AbsoluteFill><AbsoluteFill style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 40%, rgba(0,0,0,.55))' }} />
    {!capa && q >= ini && <AbsoluteFill style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: 'Inter, system-ui, sans-serif', fontWeight: 760, letterSpacing: '0.02em', fontSize: f(64, 54), textAlign: 'center', textShadow: '0 2px 30px rgba(0,0,0,.8)' }}><span>{FRASE.slice(0, Math.max(1, quantas)).join(' ')}</span></AbsoluteFill>}</AbsoluteFill>;
};
