import React from 'react';
import { Composition } from 'remotion';
import { Video, DURACAO } from './Video';
import { Frase, DURACAO_FRASE } from './Frase';
// UM vídeo, DOIS formatos. O mesmo código se adapta (ver formato.ts).
export const Root: React.FC = () => (
  <>
    <Composition id="Deitado" component={Video} durationInFrames={DURACAO} fps={30} width={1920} height={1080} />
    <Composition id="EmPe" component={Video} durationInFrames={DURACAO} fps={30} width={1080} height={1920} />
    <Composition id="FraseEmPe" component={Frase} durationInFrames={DURACAO_FRASE} fps={30} width={1080} height={1920} />
    <Composition id="FraseDeitado" component={Frase} durationInFrames={DURACAO_FRASE} fps={30} width={1920} height={1080} />
  </>
);
