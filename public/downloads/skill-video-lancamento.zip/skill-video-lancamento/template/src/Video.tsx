// EXEMPLO de uma função só ("Passos"), do começo ao fim: pergunta > toque > o app faz > resultado > resposta.
// Troque textos, cores, cenas e números. Tudo aqui é ilustrativo.
import React from 'react';
import { AbsoluteFill, Sequence, useCurrentFrame } from 'remotion';
import { useFormato } from './formato';
import { BotaoVira, Dedo, LinhaLuz, Mergulho, Negativo, Numero, Palavras, Radial, Rastro, Risco, freia, vai } from './efeitos';
export const DURACAO = 390;
const FONTE = 'Inter, "SF Pro Display", system-ui, sans-serif';
const Chao: React.FC<{ a: string; b: string }> = ({ a, b }) => <AbsoluteFill style={{ background: `radial-gradient(ellipse 80% 70% at 50% 45%, ${a}, ${b} 75%)` }} />;
const Pes: React.FC = () => { const q = useCurrentFrame(), { W, H } = useFormato(); const s = Math.sin(q * 0.32); // no seu vídeo, ponha aqui um take de verdade: <OffthreadVideo src={staticFile('corre.mp4')} />
  return <AbsoluteFill>{[s, -s].map((v, i) => <div key={i} style={{ position: 'absolute', left: W / 2 + v * W * 0.16 - 70, top: H * 0.66 - Math.max(0, -v) * 120, width: 190, height: 74, borderRadius: '60px 90px 24px 24px', background: i ? '#e8e8ee' : '#fff' }} />)}</AbsoluteFill>; };

export const Video: React.FC = () => {
  const q = useCurrentFrame(), { W, H, f, cx } = useFormato();
  const t1 = f(150, 118);
  const bw = f(760, 820), bh = 150, bx = cx - bw / 2, by = f(H * 0.66, H * 0.70);
  const linha = f(`M -40 ${H * 0.82} C ${W * 0.2} ${H * 0.6}, ${W * 0.32} ${H * 0.95}, ${W * 0.5} ${H * 0.66} S ${W * 0.8} ${H * 0.3}, ${W + 40} ${H * 0.36}`, `M -40 ${H * 0.86} C ${W * 0.3} ${H * 0.7}, ${W * 0.2} ${H * 0.62}, ${W * 0.55} ${H * 0.6} S ${W * 0.7} ${H * 0.42}, ${W + 40} ${H * 0.4}`);
  const cena2 = <AbsoluteFill><Chao a="#0f3a2a" b="#04110c" /><Rastro copias={5} atraso={2}><Pes /></Rastro></AbsoluteFill>;
  return (
    <AbsoluteFill style={{ background: '#000', color: '#fff', fontFamily: FONTE, overflow: 'hidden' }}>
      <Negativo nos={[86, 228]}>
        {q < 228 && <Radial em={88} dura={12} forca={0.35}><Mergulho em={48} dura={38} texto="[O] quanto você andou hoje?" W={W} H={H} fundo={<Chao a="#17203a" b="#05060a" />} estilo={{ fontSize: t1, fontWeight: 760, letterSpacing: '-0.045em', color: '#fff', textAlign: 'center', lineHeight: 1.02, width: f(1300, 940) }} dentro={cena2} /></Radial>}
        {q >= 94 && q < 228 && <div style={{ position: 'absolute', left: f(110, 60), top: f(90, 190), fontSize: f(110, 104) }}><Palavras texto="Abra Passos." em={96} ate={150} /></div>}
        {q >= 120 && q < 228 && <div style={{ opacity: vai(q, 120, 130), transform: `translateY(${(1 - vai(q, 120, 134)) * 80}px)` }}><BotaoVira em={196} aperta={34} x={bx} y={by} w={bw} h={bh} W={W} H={H} cor="#16a34a" rotulo="Começar" estado="Contando…" /></div>}
        <Dedo em={162} x={cx + 120} y={by + bh / 2} />
        {q >= 214 && q < 228 && <AbsoluteFill style={{ background: '#16a34a' }} />}
        {q >= 228 && <AbsoluteFill><Chao a="#151a2c" b="#04050a" /><Sequence from={228} layout="none"><LinhaLuz d={linha} em={2} dura={56} W={W} H={H} /></Sequence>
          <div style={{ position: 'absolute', left: f(110, 60), top: f(90, 190), fontSize: f(84, 84) }}><Palavras texto="Olha o seu dia." em={256} ate={352} /></div>
          <div style={{ position: 'absolute', left: f(110, 60), top: f(230, 330), fontSize: f(300, 250), opacity: 1 - vai(q, 352, 362) }}><Numero de={0} ate={8412} em={262} dura={44} /></div>
          <div style={{ position: 'absolute', left: f(124, 70), top: f(540, 600), fontSize: f(60, 60), color: '#b9bfd0', opacity: vai(q, 300, 310) * (1 - vai(q, 352, 362)) }}>passos (número de exemplo)</div>
          {q < 356 && <Risco em={312} x={f(500, 430)} y={f(390, 470)} rx={f(440, 400)} ry={f(180, 165)} cor="#3ddc6c" />}</AbsoluteFill>}
        {q >= 360 && <AbsoluteFill style={{ background: '#05060a', display: 'grid', placeItems: 'center' }}><div style={{ fontSize: f(120, 110), fontWeight: 800, letterSpacing: '-0.04em', transform: `scale(${1.6 - 0.6 * vai(q, 360, 374, freia)})`, opacity: vai(q, 360, 366) }}>SUA MARCA</div></AbsoluteFill>}
      </Negativo>
    </AbsoluteFill>
  );
};
