// Os 10 efeitos. Cada um é função pura do quadro: sempre o mesmo resultado, sem sorteio e sem relógio.
import React from 'react';
import { AbsoluteFill, Easing, Freeze, continueRender, delayRender, interpolate, useCurrentFrame, useCurrentScale } from 'remotion';

const lim = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
/** entra rápido e freia (chegada) */ export const freia = Easing.bezier(0.16, 1, 0.3, 1);
/** acelera pra sair */ export const acelera = Easing.bezier(0.7, 0, 0.84, 0);
export const vai = (q: number, a: number, b: number, e = freia) => interpolate(q, [a, b], [0, 1], { ...lim, easing: e });

/** 1. PALAVRAS QUE SAEM DO BORRÃO: uma a uma, da esquerda pra direita */
export const Palavras: React.FC<{ texto: string; em: number; ate?: number; passo?: number; style?: React.CSSProperties }> = ({ texto, em, ate = 99999, passo = 4, style }) => {
  const q = useCurrentFrame(); const s = vai(q, ate, ate + 8, acelera);
  return <div style={{ fontWeight: 740, letterSpacing: '-0.04em', lineHeight: 1, ...style, opacity: 1 - s, transform: `translateY(${-60 * s}px)`, filter: `blur(${12 * s}px)` }}>
    {texto.split(' ').map((p, i) => { const t = vai(q, em + i * passo, em + i * passo + 12); return <span key={i} style={{ display: 'inline-block', marginRight: '0.24em', opacity: t, filter: `blur(${16 * (1 - t)}px)`, transform: `translateX(${26 * (1 - t)}px)` }}>{p}</span>; })}
  </div>;
};

/** 2. MERGULHO NA LETRA: a câmera entra no miolo da letra marcada com [O] e a próxima cena já está lá dentro.
 *  Escreva o texto com a letra entre colchetes: "[O] quanto você andou hoje?". O miolo é medido sozinho. Use O, Q, D, o, d, b, p ou q. */
export const Mergulho: React.FC<{ em: number; dura?: number; texto: string; W: number; H: number; estilo: React.CSSProperties; fundo: React.ReactNode; dentro: React.ReactNode }> = ({ em, dura = 34, texto, W, H, estilo, fundo, dentro }) => {
  const q = useCurrentFrame(), escala = useCurrentScale(), ref = React.useRef<HTMLSpanElement>(null), base = React.useRef<HTMLDivElement>(null);
  const [m, setM] = React.useState<null | { x: number; y: number; rx: number; ry: number }>(null); const [espera] = React.useState(() => delayRender('medindo a letra'));
  React.useLayoutEffect(() => { const a = ref.current, b = base.current; if (a && b) { const r = a.getBoundingClientRect(), o = b.getBoundingClientRect(); const w = r.width / escala, h = r.height / escala; setM({ x: (r.left - o.left) / escala + w * 0.49, y: (r.top - o.top) / escala + h * 0.5, rx: w * 0.3, ry: h * 0.215 }); } continueRender(espera); }, []); // eslint-disable-line
  const [a, l, d] = texto.split(/\[(.)\]/); const on = q >= em && m; const t = on ? vai(q, em, em + dura, Easing.bezier(0.8, 0, 0.6, 1)) : 0;
  const alvo = m ? (Math.hypot(W, H) / Math.min(m.rx, m.ry)) * 0.62 : 1, k = Math.pow(alvo, t), px = m ? m.x + (W / 2 - m.x) * t : 0, py = m ? m.y + (H / 2 - m.y) * t : 0;
  return <AbsoluteFill>{fundo}<div ref={base} style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, display: 'flex', alignItems: 'center', justifyContent: 'center', transformOrigin: m ? `${m.x}px ${m.y}px` : undefined, transform: on ? `translate(${px - m!.x}px, ${py - m!.y}px) scale(${k})` : undefined }}><div style={estilo}>{a}<span ref={ref}>{l}</span>{d}</div></div>
    {on && <AbsoluteFill style={{ clipPath: `ellipse(${m!.rx * k}px ${m!.ry * k}px at ${px}px ${py}px)` }}>{dentro}</AbsoluteFill>}</AbsoluteFill>;
};

/** 3. NEGATIVO: 2 quadros de imagem invertida bem no corte. Nunca mais que 2. */
export const Negativo: React.FC<{ nos: number[]; children: React.ReactNode }> = ({ nos, children }) => { const q = useCurrentFrame(); const on = nos.some((n) => q >= n && q < n + 2); return <AbsoluteFill style={{ filter: on ? 'invert(1)' : 'none' }}>{children}</AbsoluteFill>; };

/** 4. BORRÃO RADIAL: a cena estoura do centro por poucos quadros */
export const Radial: React.FC<{ em: number; dura?: number; forca?: number; children: React.ReactNode }> = ({ em, dura = 12, forca = 0.5, children }) => {
  const q = useCurrentFrame(); if (q < em || q > em + dura) return <AbsoluteFill>{children}</AbsoluteFill>; const a = forca * (1 - vai(q, em, em + dura)); const N = 9;
  return <AbsoluteFill>{Array.from({ length: N }, (_, i) => <AbsoluteFill key={i} style={{ transform: `scale(${1 + (a * i) / N})`, opacity: 1 / (i + 1) }}>{children}</AbsoluteFill>)}</AbsoluteFill>;
};

/** 5. RASTRO: cópias atrasadas do movimento, como obturador aberto */
export const Rastro: React.FC<{ copias?: number; atraso?: number; children: React.ReactNode }> = ({ copias = 5, atraso = 2, children }) => { const q = useCurrentFrame();
  return <AbsoluteFill>{Array.from({ length: copias }, (_, i) => copias - 1 - i).map((i) => <AbsoluteFill key={i} style={{ opacity: i === 0 ? 1 : 0.32 * (1 - i / copias) }}><Freeze frame={Math.max(0, q - i * atraso)}>{children}</Freeze></AbsoluteFill>)}</AbsoluteFill>; };

/** 6. DEDO QUE TOCA: chega, aperta, solta um anel */
export const Dedo: React.FC<{ em: number; x: number; y: number; chega?: number }> = ({ em, x, y, chega = 14 }) => { const q = useCurrentFrame(); if (q < em - chega - 4 || q > em + 20) return null;
  const t = vai(q, em - chega, em - 3), ap = q < em ? vai(q, em - 3, em) : 1 - vai(q, em, em + 6), an = vai(q, em, em + 16), out = vai(q, em + 8, em + 18);
  return <AbsoluteFill><div style={{ position: 'absolute', left: x - 55, top: y - 55, width: 110, height: 110, borderRadius: 60, border: '4px solid #fff', opacity: 1 - an, transform: `scale(${0.6 + 1.5 * an})`, display: q < em ? 'none' : 'block' }} />
    <div style={{ position: 'absolute', left: x - 48, top: y - 48, width: 96, height: 96, borderRadius: 60, background: 'rgba(255,255,255,.35)', border: '3px solid rgba(255,255,255,.75)', opacity: t * (1 - out), transform: `translate(${(1 - t) * 170}px, ${(1 - t) * 130}px) scale(${1.25 - 0.25 * t - 0.24 * ap})` }} /></AbsoluteFill>; };

/** 7. BOTÃO QUE VIRA A PRÓXIMA CENA: o próprio botão cresce até encher a tela */
export const BotaoVira: React.FC<{ em: number; x: number; y: number; w: number; h: number; W: number; H: number; cor: string; rotulo: string; estado?: string; aperta?: number; dentro?: React.ReactNode }> = ({ em, x, y, w, h, W, H, cor, rotulo, estado, aperta = 24, dentro }) => {
  const q = useCurrentFrame(); const t = vai(q, em, em + 20, Easing.bezier(0.7, 0, 0.2, 1)); const p = q >= em - aperta && q < em - aperta + 8 ? Math.sin(((q - em + aperta) / 8) * Math.PI) * 0.06 : 0; const m = (a: number, b: number) => a + (b - a) * t;
  const troca = estado ? vai(q, em - aperta + 2, em - aperta + 8) : 0;
  return <div style={{ position: 'absolute', left: m(x, 0), top: m(y, 0), width: m(w, W), height: m(h, H), borderRadius: m(h / 2, 0), background: cor, overflow: 'hidden', transform: `scale(${1 - p})`, display: 'grid', placeItems: 'center' }}>
    <span style={{ gridArea: '1/1', color: '#fff', fontSize: h * 0.36, fontWeight: 680, opacity: (1 - troca) * (1 - vai(q, em - 4, em + 2)) }}>{rotulo}</span>{estado && <span style={{ gridArea: '1/1', color: '#fff', fontSize: h * 0.36, fontWeight: 680, opacity: troca * (1 - vai(q, em - 4, em + 2)) }}>{estado}</span>}
    {dentro && <div style={{ position: 'absolute', inset: 0, opacity: vai(q, em + 10, em + 20), filter: `blur(${20 * (1 - vai(q, em + 10, em + 24))}px)` }}>{dentro}</div>}</div>;
};

/** 8. LINHA DE LUZ que se desenha (um objeto que atravessa o vídeo inteiro) */
export const LinhaLuz: React.FC<{ d: string; em: number; dura?: number; cor?: string; grossura?: number; W: number; H: number }> = ({ d, em, dura = 40, cor = 'url(#lz)', grossura = 12, W, H }) => { const q = useCurrentFrame(); const t = vai(q, em, em + dura, Easing.bezier(0.5, 0, 0.2, 1)); if (q < em) return null;
  const P = (w: number, o: number, b: number, c = cor) => <path d={d} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${t} 1`} opacity={o} style={{ filter: b ? `blur(${b}px)` : undefined }} />;
  return <svg width={W} height={H} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}><defs><linearGradient id="lz" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2={W} y2="0"><stop offset="0" stopColor="#ff4034" /><stop offset=".5" stopColor="#ffb02e" /><stop offset="1" stopColor="#3ddc6c" /></linearGradient></defs>{P(grossura * 3, 0.5, 34)}{P(grossura * 1.8, 0.7, 12)}{P(grossura, 1, 0)}{P(grossura * 0.28, 0.75, 1, '#fff')}</svg>; };

/** 9. NÚMERO QUE ROLA e assenta */
export const Numero: React.FC<{ de: number; ate: number; em: number; dura?: number; style?: React.CSSProperties; casas?: number }> = ({ de, ate, em, dura = 36, style, casas = 0 }) => { const q = useCurrentFrame(); const t = vai(q, em, em + dura), v = de + (ate - de) * t, vel = vai(q, em, em + dura) < 1 && q > em ? 1 - t : 0;
  return <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 760, letterSpacing: '-0.05em', display: 'inline-block', filter: `blur(${vel * 7}px)`, transform: `scale(${1 + 0.06 * Math.sin(Math.min(1, Math.max(0, (q - em - dura + 4) / 10)) * Math.PI)})`, ...style }}>{v.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas })}</span>; };

/** 10. RISCO À MÃO em volta do resultado */
export const Risco: React.FC<{ em: number; x: number; y: number; rx: number; ry: number; cor?: string }> = ({ em, x, y, rx, ry, cor = '#fff' }) => { const q = useCurrentFrame(); const t = vai(q, em, em + 16, Easing.bezier(0.5, 0, 0.3, 1)); if (q < em) return null;
  const d = Array.from({ length: 46 }, (_, i) => { const a = -2.3 + (i / 45) * 6.75, k = 1 + 0.035 * Math.sin(i * 0.9) + i * 0.0016; return `${i ? 'L' : 'M'} ${x + Math.cos(a) * rx * k} ${y + Math.sin(a) * ry * k}`; }).join(' ');
  return <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}><path d={d} fill="none" stroke={cor} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${t} 1`} /></svg>; };

/** Objeto que ENCOLHE E POUSA dentro do próximo (ex.: a foto vira o check da lista) */
export const Pousa: React.FC<{ em: number; dura?: number; de: [number, number, number]; para: [number, number, number]; children: React.ReactNode }> = ({ em, dura = 22, de, para, children }) => { const q = useCurrentFrame(); const t = vai(q, em, em + dura, Easing.bezier(0.6, 0, 0.2, 1)); const k = (i: number) => de[i] + (para[i] - de[i]) * t;
  return <div style={{ position: 'absolute', left: k(0), top: k(1), transform: `translate(-50%,-50%) scale(${k(2)})`, opacity: t > 0.99 ? 0 : 1 }}>{children}</div>; };
