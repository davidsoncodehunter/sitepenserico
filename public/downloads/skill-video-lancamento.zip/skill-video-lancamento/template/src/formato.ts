import { useVideoConfig } from 'remotion';
/** Diz se é deitado ou em pé e escolhe o valor certo: const { f } = useFormato(); f(deitado, emPe) */
export const useFormato = () => {
  const { width: W, height: H } = useVideoConfig();
  const deitado = W > H;
  return { W, H, deitado, f: <T,>(d: T, e: T): T => (deitado ? d : e), cx: W / 2, cy: H / 2 };
};
